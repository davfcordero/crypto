class AnalyticsSystem {
    constructor() {
        this.data = {
            predictions: {
                total: 0,
                correct: 0,
                accuracy: 0,
                byType: {
                    buy: { total: 0, correct: 0 },
                    sell: { total: 0, correct: 0 },
                    hold: { total: 0, correct: 0 }
                }
            },
            mining: {
                totalEarnings: 0,
                dailyAverage: 0,
                efficiency: 0,
                uptime: 0,
                boostUsage: 0
            },
            portfolio: {
                value: 0,
                change24h: 0,
                performance: []
            }
        };
        this.loadState();
    }

    updatePredictionStats(signal) {
        const stats = this.data.predictions;
        stats.total++;
        stats.byType[signal.signal].total++;

        if (signal.userDecision !== null) {
            const wasCorrect = (signal.userDecision && signal.signal === 'buy') ||
                             (!signal.userDecision && signal.signal === 'sell');
            if (wasCorrect) {
                stats.correct++;
                stats.byType[signal.signal].correct++;
            }
        }

        stats.accuracy = stats.total > 0 ? (stats.correct / stats.total) : 0;
        this.saveState();
    }

    updateMiningStats(miningState) {
        const stats = this.data.mining;
        stats.totalEarnings = miningState.earnings;
        stats.dailyAverage = this.calculateDailyAverage(miningState);
        stats.efficiency = miningState.efficiency;
        stats.uptime = this.calculateUptime(miningState);
        stats.boostUsage = this.calculateBoostUsage(miningState);
        this.saveState();
    }

    calculateDailyAverage(miningState) {
        // Implementation for daily average calculation
        return miningState.hourlyEarnings * 24;
    }

    calculateUptime(miningState) {
        // Implementation for uptime calculation
        return 0.85; // Example: 85% uptime
    }

    calculateBoostUsage(miningState) {
        // Implementation for boost usage calculation
        return miningState.activeBoosts.length;
    }

    generateChartData(type, timeframe = '7d') {
        switch (type) {
            case 'earnings':
                return this.generateEarningsChart(timeframe);
            case 'accuracy':
                return this.generateAccuracyChart(timeframe);
            case 'efficiency':
                return this.generateEfficiencyChart(timeframe);
            default:
                return null;
        }
    }

    generateEarningsChart(timeframe) {
        const days = timeframe === '7d' ? 7 : 30;
        return {
            labels: Array.from({length: days}, (_, i) => `Day ${i + 1}`),
            datasets: [{
                label: 'Daily Earnings',
                data: Array.from({length: days}, () => Math.random() * 100),
                borderColor: '#6B4EFF',
                tension: 0.4
            }]
        };
    }

    generateAccuracyChart(timeframe) {
        const days = timeframe === '7d' ? 7 : 30;
        return {
            labels: Array.from({length: days}, (_, i) => `Day ${i + 1}`),
            datasets: [{
                label: 'Prediction Accuracy',
                data: Array.from({length: days}, () => Math.random() * 100),
                borderColor: '#FF4E8E',
                tension: 0.4
            }]
        };
    }

    generateEfficiencyChart(timeframe) {
        const days = timeframe === '7d' ? 7 : 30;
        return {
            labels: Array.from({length: days}, (_, i) => `Day ${i + 1}`),
            datasets: [{
                label: 'Mining Efficiency',
                data: Array.from({length: days}, () => Math.random() * 100),
                borderColor: '#4EFF8E',
                tension: 0.4
            }]
        };
    }

    saveState() {
        localStorage.setItem('analyticsState', JSON.stringify(this.data));
    }

    loadState() {
        const savedState = localStorage.getItem('analyticsState');
        if (savedState) {
            this.data = JSON.parse(savedState);
        }
    }
}

// Initialize Analytics System
const analyticsSystem = new AnalyticsSystem();

// Create charts using Chart.js
function initializeCharts() {
    const charts = {
        earnings: new Chart(
            document.getElementById('earningsChart'),
            {
                type: 'line',
                data: analyticsSystem.generateChartData('earnings'),
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Mining Earnings'
                        }
                    }
                }
            }
        ),
        accuracy: new Chart(
            document.getElementById('accuracyChart'),
            {
                type: 'line',
                data: analyticsSystem.generateChartData('accuracy'),
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Prediction Accuracy'
                        }
                    }
                }
            }
        ),
        efficiency: new Chart(
            document.getElementById('efficiencyChart'),
            {
                type: 'line',
                data: analyticsSystem.generateChartData('efficiency'),
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Mining Efficiency'
                        }
                    }
                }
            }
        )
    };

    return charts;
}

// Update charts periodically
setInterval(() => {
    const charts = initializeCharts();
    Object.values(charts).forEach(chart => {
        chart.data = analyticsSystem.generateChartData(chart.id);
        chart.update();
    });
}, 60000); // Update every minute 