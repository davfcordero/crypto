class BackgroundAnimation {
    constructor() {
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.renderer = new THREE.WebGLRenderer({ alpha: true });
        this.cubes = [];
        
        this.init();
        this.animate();
    }

    init() {
        // Setup renderer
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setClearColor(0x000000, 0);
        document.querySelector('.background-canvas').appendChild(this.renderer.domElement);

        // Create floating cubes
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        const material = new THREE.MeshPhongMaterial({
            color: 0x6B4EFF,
            transparent: true,
            opacity: 0.3,
            specular: 0xffffff
        });

        // Add multiple cubes
        for (let i = 0; i < 20; i++) {
            const cube = new THREE.Mesh(geometry, material);
            cube.position.set(
                Math.random() * 20 - 10,
                Math.random() * 20 - 10,
                Math.random() * 20 - 10
            );
            cube.rotation.set(
                Math.random() * Math.PI,
                Math.random() * Math.PI,
                Math.random() * Math.PI
            );
            this.cubes.push(cube);
            this.scene.add(cube);
        }

        // Add lights
        const light = new THREE.DirectionalLight(0xffffff, 1);
        light.position.set(1, 1, 1);
        this.scene.add(light);

        const ambientLight = new THREE.AmbientLight(0x404040);
        this.scene.add(ambientLight);

        // Position camera
        this.camera.position.z = 15;

        // Handle window resize
        window.addEventListener('resize', () => this.onWindowResize(), false);
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        // Rotate cubes
        this.cubes.forEach(cube => {
            cube.rotation.x += 0.01;
            cube.rotation.y += 0.01;
        });

        this.renderer.render(this.scene, this.camera);
    }

    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }
}

// Mining animation for the progress bar
class MiningAnimation {
    constructor() {
        this.particles = [];
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
        this.init();
    }

    init() {
        const miningCard = document.querySelector('.mining-progress');
        miningCard.appendChild(this.canvas);
        this.canvas.style.position = 'absolute';
        this.canvas.style.top = '0';
        this.canvas.style.left = '0';
        this.canvas.style.pointerEvents = 'none';
        
        this.resize();
        window.addEventListener('resize', () => this.resize());
        
        this.animate();
    }

    resize() {
        const rect = this.canvas.parentElement.getBoundingClientRect();
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
    }

    createParticle() {
        return {
            x: Math.random() * this.canvas.width,
            y: this.canvas.height + 10,
            speed: 2 + Math.random() * 2,
            radius: 1 + Math.random() * 2,
            color: `rgba(107, 78, 255, ${0.3 + Math.random() * 0.7})`
        };
    }

    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Add new particles
        if (Math.random() < 0.3) {
            this.particles.push(this.createParticle());
        }

        // Update and draw particles
        this.particles.forEach((particle, index) => {
            particle.y -= particle.speed;
            
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = particle.color;
            this.ctx.fill();

            // Remove particles that are off screen
            if (particle.y < -10) {
                this.particles.splice(index, 1);
            }
        });

        requestAnimationFrame(() => this.animate());
    }
}

// Card hover effects
function initializeCardAnimations() {
    const cards = document.querySelectorAll('.card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', (e) => {
            gsap.to(card, {
                duration: 0.3,
                transform: 'translateY(-5px) scale(1.02)',
                boxShadow: '0 8px 16px rgba(107, 78, 255, 0.2)',
                ease: 'power2.out'
            });
        });

        card.addEventListener('mouseleave', (e) => {
            gsap.to(card, {
                duration: 0.3,
                transform: 'translateY(0) scale(1)',
                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                ease: 'power2.in'
            });
        });
    });
}

// Initialize all animations
const backgroundAnimation = new BackgroundAnimation();
const miningAnimation = new MiningAnimation();
initializeCardAnimations();

// Add this CSS for the background canvas 