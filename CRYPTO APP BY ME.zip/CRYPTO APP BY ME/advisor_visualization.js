class AdvisorVisualization {
    constructor() {
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        this.advisors = new Map();
        this.activeAdvisor = null;
        this.loader = new THREE.GLTFLoader();
        
        this.init();
    }

    async init() {
        // Setup scene
        this.setupScene();
        
        // Create advisors
        await this.createAdvisors();
        
        // Add interaction
        this.setupInteraction();
        
        // Start animation loop
        this.animate();
    }

    async createAdvisors() {
        for (const type in SignalAdvisor.TYPES) {
            const advisor = new SignalAdvisor(SignalAdvisor.TYPES[type]);
            const model = await this.loadAdvisorModel(advisor.personality);
            advisor.model = model;
            
            // Position advisors in a semi-circle
            const angle = (Object.keys(SignalAdvisor.TYPES).indexOf(type) - 1) * Math.PI / 3;
            model.position.set(Math.sin(angle) * 5, 0, Math.cos(angle) * 5);
            model.rotation.y = -angle;
            
            this.scene.add(model);
            this.advisors.set(type, advisor);
        }
    }

    createSpeechBubble(text, position, color) {
        const bubble = new THREE.Group();
        
        // Create bubble background
        const bubbleGeometry = new THREE.SphereGeometry(1, 32, 32);
        const bubbleMaterial = new THREE.MeshPhongMaterial({
            color: color,
            transparent: true,
            opacity: 0.8,
        });
        const bubbleMesh = new THREE.Mesh(bubbleGeometry, bubbleMaterial);
        
        // Create text
        const textGeometry = new THREE.TextGeometry(text, {
            font: this.font,
            size: 0.1,
            height: 0.02,
        });
        const textMaterial = new THREE.MeshPhongMaterial({ color: 0xffffff });
        const textMesh = new THREE.Mesh(textGeometry, textMaterial);
        
        bubble.add(bubbleMesh);
        bubble.add(textMesh);
        bubble.position.copy(position);
        
        return bubble;
    }

    showSignal(advisor, signal) {
        const bubble = this.createSpeechBubble(
            this.generateSignalText(advisor, signal),
            advisor.model.position.clone().add(new THREE.Vector3(0, 2, 0)),
            advisor.personality.color
        );
        
        // Animate bubble appearance
        gsap.from(bubble.scale, {
            x: 0,
            y: 0,
            z: 0,
            duration: 0.5,
            ease: 'back.out',
        });
        
        // Play speak animation
        const speakAnimation = advisor.model.animations.find(a => a.name === 'speak');
        if (speakAnimation) {
            advisor.model.mixer.clipAction(speakAnimation).play();
        }
        
        // Remove bubble after delay
        setTimeout(() => {
            gsap.to(bubble.scale, {
                x: 0,
                y: 0,
                z: 0,
                duration: 0.3,
                ease: 'back.in',
                onComplete: () => {
                    this.scene.remove(bubble);
                }
            });
        }, 5000);
        
        this.scene.add(bubble);
    }

    generateSignalText(advisor, signal) {
        const style = advisor.personality.speechStyle;
        const templates = SPEECH_TEMPLATES[style];
        return templates[Math.floor(Math.random() * templates.length)]
            .replace('{symbol}', signal.cryptocurrency)
            .replace('{action}', signal.signal)
            .replace('{confidence}', Math.round(signal.confidence * 100));
    }

    setupInteraction() {
        const raycaster = new THREE.Raycaster();
        const mouse = new THREE.Vector2();

        window.addEventListener('mousemove', (event) => {
            mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
            mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

            raycaster.setFromCamera(mouse, this.camera);
            const intersects = raycaster.intersectObjects(this.scene.children, true);

            // Highlight hovered advisor
            this.advisors.forEach(advisor => {
                if (intersects.length > 0 && intersects[0].object.parent === advisor.model) {
                    gsap.to(advisor.model.scale, { x: 1.1, y: 1.1, z: 1.1, duration: 0.3 });
                } else {
                    gsap.to(advisor.model.scale, { x: 1, y: 1, z: 1, duration: 0.3 });
                }
            });
        });

        window.addEventListener('click', (event) => {
            raycaster.setFromCamera(mouse, this.camera);
            const intersects = raycaster.intersectObjects(this.scene.children, true);

            if (intersects.length > 0) {
                const clickedAdvisor = Array.from(this.advisors.values())
                    .find(advisor => intersects[0].object.parent === advisor.model);
                
                if (clickedAdvisor) {
                    this.selectAdvisor(clickedAdvisor);
                }
            }
        });
    }
}

const SPEECH_TEMPLATES = {
    cautious: [
        "After careful analysis, {symbol} shows a stable {action} signal. Confidence: {confidence}%",
        "Consider a conservative {action} position in {symbol}. Reliability: {confidence}%",
        "Low-risk opportunity: {action} {symbol} with {confidence}% certainty"
    ],
    analytical: [
        "Technical analysis suggests: {action} {symbol}. Probability: {confidence}%",
        "Market indicators for {symbol} point to {action}. Confidence level: {confidence}%",
        "Data-driven {action} signal for {symbol}. Accuracy: {confidence}%"
    ],
    bold: [
        "🚀 Hot Signal: {action} {symbol} NOW! Potential: {confidence}%",
        "Major move incoming! {action} {symbol}! Conviction: {confidence}%",
        "Don't miss this! {action} {symbol} for massive gains! Confidence: {confidence}%"
    ]
}; 