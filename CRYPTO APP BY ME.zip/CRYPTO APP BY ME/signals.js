// Signal Generation and Management
class SignalSystem {
    constructor() {
        this.signals = [];
        this.history = [];
        this.lastUpdate = Date.now();
        this.accuracy = 0;
    }

    async generateSignals() {
        // Simulate API call to get market data
        const marketData = await this.fetchMarketData();
        
        // Generate new signals
        const newSignals = marketData.map(crypto => ({
            id: `signal_${Date.now()}_${crypto.symbol}`,
            cryptocurrency: crypto.symbol,
            signal: this.determineSignal(crypto),
            prediction: this.generatePrediction(crypto),
            explanation: this.generateExplanation(crypto),
            confidence: this.calculateConfidence(crypto),
            priceHistory: crypto.prices,
            timestamp: new Date(),
            userDecision: null
        }));

        this.signals = newSignals;
        this.lastUpdate = Date.now();
        this.saveState();
    }

    async fetchMarketData() {
        try {
            const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=5&sparkline=true');
            const data = await response.json();
            return data.map(coin => ({
                symbol: coin.symbol.toUpperCase(),
                price: coin.current_price,
                change24h: coin.price_change_percentage_24h,
                prices: coin.sparkline_in_7d.price,
                volume: coin.total_volume,
                marketCap: coin.market_cap
            }));
        } catch (error) {
            console.error('Error fetching market data:', error);
            return this.getMockData();
        }
    }

    getMockData() {
        return [
            {
                symbol: 'BTC',
                price: 45000,
                change24h: 2.5,
                prices: Array(24).fill(0).map((_, i) => 45000 + Math.random() * 1000 - 500),
                volume: 25000000000,
                marketCap: 850000000000
            },
            // Add more mock data for other cryptocurrencies
        ];
    }

    determineSignal(crypto) {
        const signals = ['buy', 'sell', 'hold'];
        return signals[Math.floor(Math.random() * signals.length)];
    }

    generatePrediction(crypto) {
        const predictions = [
            `${crypto.symbol} shows strong upward momentum`,
            `${crypto.symbol} might face selling pressure`,
            `${crypto.symbol} indicates sideways movement`
        ];
        return predictions[Math.floor(Math.random() * predictions.length)];
    }

    generateExplanation(crypto) {
        return `Based on technical analysis and market sentiment, ${crypto.symbol} ${
            crypto.change24h > 0 ? 'shows positive momentum' : 'might face resistance'
        }. Volume and market indicators suggest ${
            Math.random() > 0.5 ? 'potential growth' : 'possible consolidation'
        }.`;
    }

    calculateConfidence(crypto) {
        return 0.5 + (Math.random() * 0.4); // 50-90% confidence
    }

    handleSignalDecision(signalId, approved) {
        const signal = this.signals.find(s => s.id === signalId);
        if (signal) {
            signal.userDecision = approved;
            this.history.push({...signal});
            this.signals = this.signals.filter(s => s.id !== signalId);
            this.updateAccuracy();
            this.saveState();
        }
    }

    updateAccuracy() {
        const decidedSignals = this.history.filter(s => s.userDecision !== null);
        if (decidedSignals.length === 0) return;

        const correctPredictions = decidedSignals.filter(s => {
            const wasCorrect = s.userDecision && s.signal === 'buy' ||
                             !s.userDecision && s.signal === 'sell';
            return wasCorrect;
        }).length;

        this.accuracy = correctPredictions / decidedSignals.length;
    }

    saveState() {
        localStorage.setItem('signalState', JSON.stringify({
            signals: this.signals,
            history: this.history,
            lastUpdate: this.lastUpdate,
            accuracy: this.accuracy
        }));
    }

    loadState() {
        const savedState = localStorage.getItem('signalState');
        if (savedState) {
            const data = JSON.parse(savedState);
            Object.assign(this, data);
        }
    }
}

// Initialize Signal System
const signalSystem = new SignalSystem();
signalSystem.loadState();

// Update signals every hour
setInterval(() => signalSystem.generateSignals(), 3600000); 