const vertexShader = `
varying vec2 vUv;
void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const fragmentShader = `
uniform float time;
uniform vec2 resolution;
varying vec2 vUv;

float random(vec2 st) {
    return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
}

void main() {
    vec2 st = gl_FragCoord.xy/resolution.xy;
    float r = random(st + time * 0.1);
    
    // Create grid pattern
    vec2 grid = fract(st * 20.0);
    float cell = step(0.9, grid.x) + step(0.9, grid.y);
    
    // Crypto symbols pattern
    float symbol = step(0.95, r);
    
    vec3 color = vec3(0.42, 0.31, 1.0); // Primary color
    color *= mix(0.2, 1.0, cell + symbol);
    color += vec3(0.1) * sin(time + st.x * 10.0);
    
    gl_FragColor = vec4(color, 0.3);
}
`; 