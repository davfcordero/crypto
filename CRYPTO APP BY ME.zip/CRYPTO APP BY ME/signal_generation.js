class SignalGenerator {
    constructor() {
        this.technicalIndicators = new TechnicalIndicators();
        this.marketSentiment = new MarketSentiment();
    }

    async generateSignalsForAdvisor(advisor, marketData) {
        const { personality } = advisor;
        const signals = [];

        for (const crypto of marketData) {
            const analysis = await this.analyzeMarket(crypto);
            
            // Filter signals based on advisor's risk profile
            if (this.matchesRiskProfile(analysis, personality)) {
                const signal = this.createSignal(crypto, analysis, personality);
                signals.push(signal);
            }
        }

        return signals.sort((a, b) => b.confidence - a.confidence);
    }

    async analyzeMarket(crypto) {
        const technical = await this.technicalIndicators.analyze(crypto);
        const sentiment = await this.marketSentiment.analyze(crypto);
        
        return {
            technical,
            sentiment,
            volatility: this.calculateVolatility(crypto),
            momentum: this.calculateMomentum(crypto),
            risk: this.assessRisk(technical, sentiment)
        };
    }

    matchesRiskProfile(analysis, personality) {
        const { riskTolerance, minConfidence } = personality;
        const signalConfidence = this.calculateConfidence(analysis);
        
        return analysis.risk <= riskTolerance && signalConfidence >= minConfidence;
    }

    createSignal(crypto, analysis, personality) {
        const signal = {
            cryptocurrency: crypto.symbol,
            signal: this.determineSignalType(analysis, personality),
            confidence: this.calculateConfidence(analysis),
            timestamp: new Date(),
            analysis: {
                technical: analysis.technical,
                sentiment: analysis.sentiment,
                risk: analysis.risk
            },
            advisor: personality.name
        };

        return signal;
    }
}

class TechnicalIndicators {
    async analyze(crypto) {
        return {
            rsi: this.calculateRSI(crypto.priceHistory),
            macd: this.calculateMACD(crypto.priceHistory),
            movingAverages: this.calculateMovingAverages(crypto.priceHistory),
            supportResistance: this.findSupportResistance(crypto.priceHistory)
        };
    }

    // Technical analysis implementations...
}

class MarketSentiment {
    async analyze(crypto) {
        return {
            socialMediaSentiment: await this.analyzeSocialMedia(crypto.symbol),
            newsAnalysis: await this.analyzeNews(crypto.symbol),
            marketMomentum: this.analyzeMomentum(crypto)
        };
    }

    // Sentiment analysis implementations...
} 