// Enhanced 3D animations for cards
class CardAnimator {
    constructor() {
        this.cards = document.querySelectorAll('.card');
        this.init();
    }

    init() {
        this.cards.forEach(card => {
            // Add 3D perspective to cards
            card.style.transform = 'perspective(1000px)';
            
            // Create 3D hover effect
            card.addEventListener('mousemove', (e) => this.handleHover(e, card));
            card.addEventListener('mouseleave', (e) => this.resetCard(card));
            card.addEventListener('mouseenter', (e) => this.addGlow(card));
        });
    }

    handleHover(e, card) {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = (y - centerY) / 20;
        const rotateY = (centerX - x) / 20;

        gsap.to(card, {
            duration: 0.3,
            rotateX: rotateX,
            rotateY: rotateY,
            scale: 1.05,
            boxShadow: '0 20px 40px rgba(107, 78, 255, 0.2)',
            ease: 'power2.out'
        });
    }

    resetCard(card) {
        gsap.to(card, {
            duration: 0.5,
            rotateX: 0,
            rotateY: 0,
            scale: 1,
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
            ease: 'power3.out'
        });
    }

    addGlow(card) {
        const glow = document.createElement('div');
        glow.className = 'card-glow';
        card.appendChild(glow);
        
        gsap.fromTo(glow, 
            { opacity: 0 },
            { 
                opacity: 0.5,
                duration: 0.5,
                onComplete: () => glow.remove()
            }
        );
    }
}

// Enhanced particle system
class ParticleSystem {
    constructor() {
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.mousePosition = { x: 0, y: 0 };
        this.init();
    }

    init() {
        document.body.appendChild(this.canvas);
        this.canvas.style.position = 'fixed';
        this.canvas.style.top = '0';
        this.canvas.style.left = '0';
        this.canvas.style.pointerEvents = 'none';
        this.canvas.style.zIndex = '1';
        
        this.resize();
        window.addEventListener('resize', () => this.resize());
        document.addEventListener('mousemove', (e) => this.updateMousePosition(e));
        
        this.animate();
    }

    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    updateMousePosition(e) {
        this.mousePosition.x = e.clientX;
        this.mousePosition.y = e.clientY;
        this.createParticles(5);
    }

    createParticles(count) {
        for (let i = 0; i < count; i++) {
            this.particles.push({
                x: this.mousePosition.x,
                y: this.mousePosition.y,
                size: Math.random() * 3 + 1,
                speedX: Math.random() * 4 - 2,
                speedY: Math.random() * 4 - 2,
                life: 1,
                color: `hsla(${Math.random() * 60 + 240}, 70%, 50%, `
            });
        }
    }

    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.particles.forEach((particle, index) => {
            particle.x += particle.speedX;
            particle.y += particle.speedY;
            particle.life -= 0.02;
            
            this.ctx.beginPath();
            this.ctx.arc(
                particle.x,
                particle.y,
                particle.size,
                0,
                Math.PI * 2
            );
            this.ctx.fillStyle = particle.color + particle.life + ')';
            this.ctx.fill();
            
            if (particle.life <= 0) {
                this.particles.splice(index, 1);
            }
        });
        
        requestAnimationFrame(() => this.animate());
    }
}

// Enhanced 3D background
class EnhancedBackground extends BackgroundAnimation {
    constructor() {
        super();
        this.addFloatingSymbols();
    }

    addFloatingSymbols() {
        const symbols = ['₿', 'Ξ', '◈', '∞'];
        const textGeometry = new THREE.TextGeometry('₿', {
            font: new THREE.Font(), // You'll need to load a font
            size: 1,
            height: 0.2,
        });

        symbols.forEach((symbol, index) => {
            const material = new THREE.MeshPhongMaterial({
                color: 0x6B4EFF,
                transparent: true,
                opacity: 0.2
            });
            
            const mesh = new THREE.Mesh(textGeometry, material);
            mesh.position.set(
                Math.random() * 20 - 10,
                Math.random() * 20 - 10,
                Math.random() * 20 - 10
            );
            
            this.scene.add(mesh);
            this.cubes.push(mesh);
        });
    }
}

// Initialize enhanced animations
const cardAnimator = new CardAnimator();
const particleSystem = new ParticleSystem();
const enhancedBackground = new EnhancedBackground();

// Add these styles to animations.css 