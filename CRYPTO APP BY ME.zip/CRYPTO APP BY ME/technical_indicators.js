class TechnicalIndicators {
    constructor() {
        this.periods = {
            rsi: 14,
            macd: { short: 12, long: 26, signal: 9 },
            ma: { short: 50, long: 200 }
        };
    }

    async analyze(crypto) {
        const priceHistory = crypto.priceHistory;
        
        return {
            rsi: this.calculateRSI(priceHistory),
            macd: this.calculateMACD(priceHistory),
            movingAverages: this.calculateMovingAverages(priceHistory),
            supportResistance: this.findSupportResistance(priceHistory),
            trends: this.analyzeTrends(priceHistory),
            volatility: this.calculateVolatility(priceHistory),
            patterns: this.detectPatterns(priceHistory)
        };
    }

    calculateRSI(prices) {
        let gains = 0;
        let losses = 0;
        
        for (let i = 1; i < this.periods.rsi; i++) {
            const difference = prices[i] - prices[i - 1];
            if (difference >= 0) {
                gains += difference;
            } else {
                losses -= difference;
            }
        }

        const avgGain = gains / this.periods.rsi;
        const avgLoss = losses / this.periods.rsi;
        const rs = avgGain / avgLoss;
        const rsi = 100 - (100 / (1 + rs));

        return {
            value: rsi,
            signal: this.interpretRSI(rsi),
            strength: this.calculateIndicatorStrength(rsi, 30, 70)
        };
    }

    calculateMACD(prices) {
        const shortEMA = this.calculateEMA(prices, this.periods.macd.short);
        const longEMA = this.calculateEMA(prices, this.periods.macd.long);
        const macdLine = shortEMA - longEMA;
        const signalLine = this.calculateEMA([macdLine], this.periods.macd.signal);
        const histogram = macdLine - signalLine;

        return {
            macdLine,
            signalLine,
            histogram,
            signal: this.interpretMACD(macdLine, signalLine, histogram),
            strength: this.calculateIndicatorStrength(Math.abs(histogram), 0, 2)
        };
    }

    calculateMovingAverages(prices) {
        const sma50 = this.calculateSMA(prices, this.periods.ma.short);
        const sma200 = this.calculateSMA(prices, this.periods.ma.long);
        const currentPrice = prices[prices.length - 1];

        return {
            sma50,
            sma200,
            crossover: this.detectCrossover(prices, sma50, sma200),
            trend: this.determineTrend(currentPrice, sma50, sma200),
            strength: this.calculateMAStrength(currentPrice, sma50, sma200)
        };
    }

    detectPatterns(prices) {
        return {
            doubleTop: this.findDoubleTop(prices),
            doubleBottom: this.findDoubleBottom(prices),
            headAndShoulders: this.findHeadAndShoulders(prices),
            triangles: this.findTriangles(prices),
            channels: this.findChannels(prices)
        };
    }

    calculateVolatility(prices) {
        const returns = [];
        for (let i = 1; i < prices.length; i++) {
            returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
        }

        const mean = returns.reduce((a, b) => a + b) / returns.length;
        const variance = returns.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / returns.length;
        const volatility = Math.sqrt(variance);

        return {
            value: volatility,
            annualized: volatility * Math.sqrt(365),
            risk: this.categorizeVolatility(volatility)
        };
    }

    findSupportResistance(prices) {
        const levels = this.findPivotPoints(prices);
        return {
            support: this.identifySupport(levels, prices),
            resistance: this.identifyResistance(levels, prices),
            strength: this.calculateLevelStrength(levels, prices)
        };
    }

    // Helper methods
    calculateEMA(prices, period) {
        const multiplier = 2 / (period + 1);
        let ema = prices[0];
        
        for (let i = 1; i < prices.length; i++) {
            ema = (prices[i] - ema) * multiplier + ema;
        }
        
        return ema;
    }

    calculateSMA(prices, period) {
        return prices.slice(-period).reduce((a, b) => a + b) / period;
    }

    interpretRSI(value) {
        if (value >= 70) return 'overbought';
        if (value <= 30) return 'oversold';
        return 'neutral';
    }

    interpretMACD(macdLine, signalLine, histogram) {
        if (macdLine > signalLine && histogram > 0) return 'bullish';
        if (macdLine < signalLine && histogram < 0) return 'bearish';
        return 'neutral';
    }

    calculateIndicatorStrength(value, min, max) {
        return (value - min) / (max - min);
    }
} 