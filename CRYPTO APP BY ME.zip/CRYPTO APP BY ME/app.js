// State management
class MiningState {
    constructor() {
        this.hashPower = 50.0;
        this.earnings = 0.0;
        this.gpuCount = 1;
        this.efficiency = 1.0;
        this.isAutoMining = false;
        this.powerConsumption = 200.0;
        this.dailyOperatingCost = 5.0;
        this.difficulty = 1.0;
        this.activeBoosts = [];
        this.lastBoostUsed = Date.now() - (4 * 60 * 60 * 1000); // 4 hours ago
        this.miningInterval = null;
    }

    get totalMultiplier() {
        return this.activeBoosts.reduce((total, boost) => {
            if (!boost.isExpired) {
                return total * boost.multiplier;
            }
            return total;
        }, 1.0);
    }

    get hourlyEarnings() {
        return (this.hashPower * this.efficiency * this.totalMultiplier) / (this.difficulty * 100);
    }

    get dailyProfit() {
        return (this.hourlyEarnings * 24) - this.dailyOperatingCost;
    }
}

// Initialize state
const state = new MiningState();
loadState();

// DOM Elements
const toggleMiningBtn = document.getElementById('toggleMining');
const toggleMiningIcon = toggleMiningBtn.querySelector('.material-icons');
const progressFill = document.querySelector('.progress-fill');
const hashRateElement = document.getElementById('hashRate');
const hourlyEarningsElement = document.getElementById('hourlyEarnings');
const totalEarningsElement = document.getElementById('totalEarnings');
const dailyProfitElement = document.getElementById('dailyProfit');
const powerUsageElement = document.getElementById('powerUsage');
const operatingCostElement = document.getElementById('operatingCost');
const gpuCountElement = document.getElementById('gpuCount');
const efficiencySlider = document.getElementById('efficiency');
const efficiencyValueElement = document.getElementById('efficiencyValue');
const boostButton = document.getElementById('boostButton');
const boostsList = document.getElementById('boostsList');

// Event Listeners
toggleMiningBtn.addEventListener('click', toggleMining);
document.getElementById('addGPU').addEventListener('click', addGPU);
document.getElementById('removeGPU').addEventListener('click', removeGPU);
efficiencySlider.addEventListener('input', updateEfficiency);
boostButton.addEventListener('click', activateBoost);

// Mining Functions
function toggleMining() {
    state.isAutoMining = !state.isAutoMining;
    toggleMiningIcon.textContent = state.isAutoMining ? 'pause' : 'play_arrow';
    
    if (state.isAutoMining) {
        startMining();
    } else {
        stopMining();
    }
    saveState();
}

function startMining() {
    if (state.miningInterval) return;
    
    let progress = 0;
    state.miningInterval = setInterval(() => {
        progress = (progress + 1) % 100;
        progressFill.style.width = `${progress}%`;
        
        const earnings = state.hourlyEarnings / 3600; // Per second
        state.earnings += earnings;
        updateUI();
        saveState();
    }, 1000);
}

function stopMining() {
    if (state.miningInterval) {
        clearInterval(state.miningInterval);
        state.miningInterval = null;
        progressFill.style.width = '0%';
    }
}

// GPU Management
function addGPU() {
    if (state.gpuCount < 8) {
        state.gpuCount++;
        state.hashPower += 50.0;
        state.powerConsumption += 200.0;
        state.dailyOperatingCost += 5.0;
        updateUI();
        saveState();
    }
}

function removeGPU() {
    if (state.gpuCount > 1) {
        state.gpuCount--;
        state.hashPower -= 50.0;
        state.powerConsumption -= 200.0;
        state.dailyOperatingCost -= 5.0;
        updateUI();
        saveState();
    }
}

function updateEfficiency(event) {
    state.efficiency = parseInt(event.target.value) / 100;
    updateUI();
    saveState();
}

// Boost System
function activateBoost() {
    if (canUseBoost()) {
        const boost = {
            id: `boost_${Date.now()}`,
            title: '2x Mining Boost',
            multiplier: 2.0,
            duration: 3600000, // 1 hour in milliseconds
            startTime: Date.now(),
            get isExpired() {
                return Date.now() > this.startTime + this.duration;
            }
        };

        state.activeBoosts.push(boost);
        state.lastBoostUsed = Date.now();
        updateUI();
        saveState();
        updateBoostButton();
        renderActiveBoosts();
    }
}

function canUseBoost() {
    return Date.now() - state.lastBoostUsed >= 4 * 60 * 60 * 1000; // 4 hours
}

function updateBoostButton() {
    const timeUntilNextBoost = (state.lastBoostUsed + (4 * 60 * 60 * 1000)) - Date.now();
    
    if (timeUntilNextBoost > 0) {
        const minutes = Math.floor(timeUntilNextBoost / 60000);
        const seconds = Math.floor((timeUntilNextBoost % 60000) / 1000);
        boostButton.disabled = true;
        boostButton.innerHTML = `
            <span class="material-icons">timer</span>
            <span>${minutes}:${seconds.toString().padStart(2, '0')}</span>
        `;
    } else {
        boostButton.disabled = false;
        boostButton.innerHTML = `
            <span class="material-icons">rocket_launch</span>
            <span>Activate Boost</span>
        `;
    }
}

// UI Updates
function updateUI() {
    hashRateElement.textContent = `${state.hashPower.toFixed(1)} H/s`;
    hourlyEarningsElement.textContent = `${state.hourlyEarnings.toFixed(2)} CT`;
    totalEarningsElement.textContent = `${state.earnings.toFixed(2)} CT`;
    dailyProfitElement.textContent = `${state.dailyProfit.toFixed(2)} CT`;
    powerUsageElement.textContent = `${state.powerConsumption.toFixed(0)}W`;
    operatingCostElement.textContent = `${state.dailyOperatingCost.toFixed(2)} CT/day`;
    gpuCountElement.textContent = state.gpuCount;
    efficiencyValueElement.textContent = `${(state.efficiency * 100).toFixed(0)}`;
    efficiencySlider.value = state.efficiency * 100;
}

function renderActiveBoosts() {
    boostsList.innerHTML = state.activeBoosts
        .filter(boost => !boost.isExpired)
        .map(boost => `
            <div class="stat-item">
                <span class="material-icons">rocket_launch</span>
                <span class="label">${boost.title}</span>
                <span class="value">${boost.multiplier}x</span>
            </div>
        `).join('');
}

// State Persistence
function saveState() {
    const saveData = {
        hashPower: state.hashPower,
        earnings: state.earnings,
        gpuCount: state.gpuCount,
        efficiency: state.efficiency,
        isAutoMining: state.isAutoMining,
        powerConsumption: state.powerConsumption,
        dailyOperatingCost: state.dailyOperatingCost,
        lastBoostUsed: state.lastBoostUsed,
        activeBoosts: state.activeBoosts,
    };
    localStorage.setItem('miningState', JSON.stringify(saveData));
}

function loadState() {
    const savedState = localStorage.getItem('miningState');
    if (savedState) {
        const data = JSON.parse(savedState);
        Object.assign(state, data);
        if (state.isAutoMining) {
            startMining();
        }
    }
}

// Initialize UI
updateUI();
updateBoostButton();
renderActiveBoosts();

// Update boost button every second
setInterval(updateBoostButton, 1000);

// Clean up expired boosts every minute
setInterval(() => {
    state.activeBoosts = state.activeBoosts.filter(boost => !boost.isExpired);
    renderActiveBoosts();
    updateUI();
    saveState();
}, 60000); 