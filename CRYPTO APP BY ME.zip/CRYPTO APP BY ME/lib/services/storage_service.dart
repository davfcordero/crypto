import 'package:shared_preferences.dart';
import 'dart:convert';

class StorageService {
  static const String _settingsKey = 'user_settings';
  static const String _signalHistoryKey = 'signal_history';
  static const String _miningStatsKey = 'mining_stats';

  final SharedPreferences _prefs;

  StorageService(this._prefs);

  Future<void> saveSettings(Map<String, dynamic> settings) async {
    await _prefs.setString(_settingsKey, jsonEncode(settings));
  }

  Map<String, dynamic>? getSettings() {
    final data = _prefs.getString(_settingsKey);
    if (data == null) return null;
    return jsonDecode(data);
  }

  Future<void> saveSignalHistory(List<Map<String, dynamic>> history) async {
    await _prefs.setString(_signalHistoryKey, jsonEncode(history));
  }

  List<Map<String, dynamic>> getSignalHistory() {
    final data = _prefs.getString(_signalHistoryKey);
    if (data == null) return [];
    return List<Map<String, dynamic>>.from(jsonDecode(data));
  }

  Future<void> saveMiningStats(Map<String, dynamic> stats) async {
    await _prefs.setString(_miningStatsKey, jsonEncode(stats));
  }

  Map<String, dynamic>? getMiningStats() {
    final data = _prefs.getString(_miningStatsKey);
    if (data == null) return null;
    return jsonDecode(data);
  }
} 