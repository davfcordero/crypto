import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/market_data.dart';
import 'package:crypto_tarot/models/prediction.dart';

final aiServiceProvider = Provider((ref) => AIService());

class AIService {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: 'https://api.openai.com/v1',
    headers: {
      'Authorization': 'Bearer YOUR_OPENAI_API_KEY',
      'Content-Type': 'application/json',
    },
  ));

  Future<List<Prediction>> generatePredictions(List<MarketData> marketData) async {
    try {
      final response = await _dio.post(
        '/chat/completions',
        data: {
          'model': 'gpt-3.5-turbo',
          'messages': [
            {
              'role': 'system',
              'content': 'You are a crypto market analyst. Analyze the given market data and provide trading signals.',
            },
            {
              'role': 'user',
              'content': _formatMarketDataPrompt(marketData),
            },
          ],
        },
      );

      if (response.statusCode == 200) {
        return _parsePredictions(response.data['choices'][0]['message']['content']);
      } else {
        throw Exception('Failed to generate predictions');
      }
    } catch (e) {
      throw Exception('Error generating predictions: $e');
    }
  }

  String _formatMarketDataPrompt(List<MarketData> marketData) {
    return '''
    Analyze the following cryptocurrency market data and provide trading signals:
    ${marketData.map((data) => '''
    ${data.symbol.toUpperCase()}:
    - Current Price: \$${data.currentPrice}
    - 24h Change: ${data.priceChangePercentage24h}%
    - Market Cap: \$${data.marketCap}
    ''').join('\n')}
    
    For each cryptocurrency, provide:
    1. A trading signal (Buy/Sell/Hold)
    2. A brief prediction
    3. A detailed explanation
    4. A confidence score (0-1)
    ''';
  }

  List<Prediction> _parsePredictions(String aiResponse) {
    // In a real implementation, you would parse the AI response
    // For now, return mock predictions
    return [
      Prediction(
        id: '1',
        cryptocurrency: 'BTC',
        signal: 'Buy',
        prediction: 'Bitcoin likely to surge',
        explanation: 'Technical indicators suggest a bullish trend...',
        confidence: 0.85,
      ),
      // Add more mock predictions...
    ];
  }

  Future<Map<String, dynamic>> generatePrediction(MarketData data) async {
    // In a real app, this would call an AI model API
    // For now, we'll simulate predictions
    await Future.delayed(const Duration(milliseconds: 500));
    
    final sentiment = _analyzeSentiment(data);
    final trend = _analyzeTrend(data.priceHistory);
    
    return {
      'prediction': _generatePredictionText(sentiment, trend),
      'signal': _determineSignal(sentiment, trend),
      'confidence': _calculateConfidence(sentiment, trend),
    };
  }

  double _analyzeSentiment(MarketData data) {
    // Simulate sentiment analysis
    final priceChange = data.priceChangePercentage24h;
    return (priceChange + 100) / 200; // Normalize to 0-1
  }

  String _analyzeTrend(List<double> prices) {
    if (prices.length < 2) return 'neutral';
    
    final lastPrice = prices.last;
    final firstPrice = prices.first;
    
    if (lastPrice > firstPrice * 1.05) return 'bullish';
    if (lastPrice < firstPrice * 0.95) return 'bearish';
    return 'neutral';
  }

  String _generatePredictionText(double sentiment, String trend) {
    if (trend == 'bullish' && sentiment > 0.6) {
      return 'Strong upward momentum with positive market sentiment';
    } else if (trend == 'bearish' && sentiment < 0.4) {
      return 'Downward pressure with negative market sentiment';
    }
    return 'Market showing mixed signals with neutral sentiment';
  }

  String _determineSignal(double sentiment, String trend) {
    if (trend == 'bullish' && sentiment > 0.6) return 'buy';
    if (trend == 'bearish' && sentiment < 0.4) return 'sell';
    return 'hold';
  }

  double _calculateConfidence(double sentiment, String trend) {
    switch (trend) {
      case 'bullish':
        return 0.5 + (sentiment * 0.5);
      case 'bearish':
        return 0.5 + ((1 - sentiment) * 0.5);
      default:
        return 0.5;
    }
  }
} 