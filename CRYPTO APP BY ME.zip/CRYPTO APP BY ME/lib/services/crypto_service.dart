import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/market_data.dart';

final cryptoServiceProvider = Provider((ref) => CryptoService());

class CryptoService {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: 'https://api.coingecko.com/api/v3',
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 10),
  ));

  Future<List<MarketData>> getTopCryptos({int limit = 20}) async {
    try {
      final response = await _dio.get(
        '/coins/markets',
        queryParameters: {
          'vs_currency': 'usd',
          'order': 'market_cap_desc',
          'per_page': limit,
          'sparkline': true,
          'price_change_percentage': '24h,7d',
        },
      );

      if (response.statusCode == 200) {
        return (response.data as List)
            .map((json) => MarketData.fromJson(json))
            .toList();
      } else {
        throw Exception('Failed to fetch crypto data');
      }
    } catch (e) {
      throw Exception('Error fetching crypto data: $e');
    }
  }

  Future<Map<String, dynamic>> getCryptoDetails(String id) async {
    try {
      final response = await _dio.get('/coins/$id');
      
      if (response.statusCode == 200) {
        return response.data;
      } else {
        throw Exception('Failed to fetch crypto details');
      }
    } catch (e) {
      throw Exception('Error fetching crypto details: $e');
    }
  }

  Future<List<Map<String, dynamic>>> getTrendingCryptos() async {
    try {
      final response = await _dio.get('/search/trending');
      
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(response.data['coins']);
      } else {
        throw Exception('Failed to fetch trending cryptos');
      }
    } catch (e) {
      throw Exception('Error fetching trending cryptos: $e');
    }
  }
} 