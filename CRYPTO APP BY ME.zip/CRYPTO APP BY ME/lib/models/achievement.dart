class Achievement {
  final String id;
  final String title;
  final String description;
  final String icon;
  final int points;
  final bool isUnlocked;
  final double progress;
  final int targetValue;
  final int currentValue;

  Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.points,
    this.isUnlocked = false,
    this.progress = 0.0,
    required this.targetValue,
    this.currentValue = 0,
  });
} 