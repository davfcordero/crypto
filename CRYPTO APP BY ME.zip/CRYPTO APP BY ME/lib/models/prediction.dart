class Prediction {
  final String id;
  final String cryptocurrency;
  final String signal;
  final String prediction;
  final String explanation;
  final double confidence;

  Prediction({
    required this.id,
    required this.cryptocurrency,
    required this.signal,
    required this.prediction,
    required this.explanation,
    required this.confidence,
  });
} 