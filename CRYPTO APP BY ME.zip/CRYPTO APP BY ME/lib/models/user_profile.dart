class UserProfile {
  final String id;
  final String username;
  final String avatarUrl;
  final int level;
  final int totalPoints;
  final int predictionAccuracy;
  final double totalEarnings;
  final int dailyStreak;
  final List<String> achievements;
  final DateTime joinedDate;

  UserProfile({
    required this.id,
    required this.username,
    required this.avatarUrl,
    required this.level,
    required this.totalPoints,
    required this.predictionAccuracy,
    required this.totalEarnings,
    required this.dailyStreak,
    required this.achievements,
    required this.joinedDate,
  });

  UserProfile copyWith({
    int? level,
    int? totalPoints,
    int? predictionAccuracy,
    double? totalEarnings,
    int? dailyStreak,
    List<String>? achievements,
  }) {
    return UserProfile(
      id: id,
      username: username,
      avatarUrl: avatarUrl,
      level: level ?? this.level,
      totalPoints: totalPoints ?? this.totalPoints,
      predictionAccuracy: predictionAccuracy ?? this.predictionAccuracy,
      totalEarnings: totalEarnings ?? this.totalEarnings,
      dailyStreak: dailyStreak ?? this.dailyStreak,
      achievements: achievements ?? this.achievements,
      joinedDate: joinedDate,
    );
  }
} 