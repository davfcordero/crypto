class MiningStats {
  final double hashPower;
  final double earnings;
  final int level;
  final List<MiningReward> activeRewards;
  final DateTime lastBoostUsed;
  final double difficulty;
  final double efficiency;
  final int gpuCount;
  final bool isAutoMining;
  final double powerConsumption;
  final double dailyOperatingCost;

  MiningStats({
    this.hashPower = 50.0,
    this.earnings = 0.0,
    this.level = 1,
    this.activeRewards = const [],
    this.difficulty = 1.0,
    this.efficiency = 1.0,
    this.gpuCount = 1,
    this.isAutoMining = false,
    this.powerConsumption = 200.0,
    this.dailyOperatingCost = 5.0,
    DateTime? lastBoostUsed,
  }) : lastBoostUsed = lastBoostUsed ?? DateTime.now().subtract(const Duration(hours: 24));

  double get totalMultiplier {
    return activeRewards.fold(
      1.0,
      (total, reward) => total * (reward.isActive && !reward.isExpired ? reward.multiplier : 1.0),
    );
  }

  double get hourlyEarnings {
    return (hashPower * efficiency * totalMultiplier) / (difficulty * 100);
  }

  double get dailyProfit {
    return (hourlyEarnings * 24) - dailyOperatingCost;
  }

  MiningStats copyWith({
    double? hashPower,
    double? earnings,
    int? level,
    List<MiningReward>? activeRewards,
    DateTime? lastBoostUsed,
    double? difficulty,
    double? efficiency,
    int? gpuCount,
    bool? isAutoMining,
    double? powerConsumption,
    double? dailyOperatingCost,
  }) {
    return MiningStats(
      hashPower: hashPower ?? this.hashPower,
      earnings: earnings ?? this.earnings,
      level: level ?? this.level,
      activeRewards: activeRewards ?? this.activeRewards,
      lastBoostUsed: lastBoostUsed ?? this.lastBoostUsed,
      difficulty: difficulty ?? this.difficulty,
      efficiency: efficiency ?? this.efficiency,
      gpuCount: gpuCount ?? this.gpuCount,
      isAutoMining: isAutoMining ?? this.isAutoMining,
      powerConsumption: powerConsumption ?? this.powerConsumption,
      dailyOperatingCost: dailyOperatingCost ?? this.dailyOperatingCost,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'hashPower': hashPower,
      'earnings': earnings,
      'level': level,
      'difficulty': difficulty,
      'efficiency': efficiency,
      'gpuCount': gpuCount,
      'isAutoMining': isAutoMining,
      'powerConsumption': powerConsumption,
      'dailyOperatingCost': dailyOperatingCost,
      'lastBoostUsed': lastBoostUsed.toIso8601String(),
    };
  }

  factory MiningStats.fromJson(Map<String, dynamic> json) {
    return MiningStats(
      hashPower: json['hashPower'],
      earnings: json['earnings'],
      level: json['level'],
      difficulty: json['difficulty'],
      efficiency: json['efficiency'],
      gpuCount: json['gpuCount'],
      isAutoMining: json['isAutoMining'],
      powerConsumption: json['powerConsumption'],
      dailyOperatingCost: json['dailyOperatingCost'],
      lastBoostUsed: DateTime.parse(json['lastBoostUsed']),
    );
  }
} 