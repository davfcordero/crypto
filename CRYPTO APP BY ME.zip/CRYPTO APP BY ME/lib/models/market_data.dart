class MarketData {
  final String id;
  final String symbol;
  final String name;
  final double currentPrice;
  final double priceChangePercentage24h;
  final double priceChangePercentage7d;
  final List<double> priceHistory;
  final double marketCap;
  final double volume24h;

  MarketData({
    required this.id,
    required this.symbol,
    required this.name,
    required this.currentPrice,
    required this.priceChangePercentage24h,
    required this.priceChangePercentage7d,
    required this.priceHistory,
    required this.marketCap,
    required this.volume24h,
  });

  factory MarketData.fromJson(Map<String, dynamic> json) {
    return MarketData(
      id: json['id'],
      symbol: json['symbol'],
      name: json['name'],
      currentPrice: json['current_price'].toDouble(),
      priceChangePercentage24h: json['price_change_percentage_24h'].toDouble(),
      priceChangePercentage7d: json['price_change_percentage_7d'].toDouble(),
      priceHistory: List<double>.from(json['sparkline_in_7d']['price']),
      marketCap: json['market_cap'].toDouble(),
      volume24h: json['total_volume'].toDouble(),
    );
  }
} 