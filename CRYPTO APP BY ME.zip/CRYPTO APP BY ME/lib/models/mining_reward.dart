class MiningReward {
  final String id;
  final String title;
  final String description;
  final double multiplier;
  final Duration duration;
  final DateTime? expiresAt;
  final bool isActive;

  MiningReward({
    required this.id,
    required this.title,
    required this.description,
    required this.multiplier,
    required this.duration,
    this.expiresAt,
    this.isActive = true,
  });

  bool get isExpired => expiresAt != null && DateTime.now().isAfter(expiresAt!);
} 