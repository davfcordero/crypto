class DailyChallenge {
  final String id;
  final String title;
  final String description;
  final int requiredAmount;
  final int currentAmount;
  final String type; // 'mining', 'prediction', 'streak'
  final int rewardPoints;
  final DateTime expiresAt;
  final bool isCompleted;

  DailyChallenge({
    required this.id,
    required this.title,
    required this.description,
    required this.requiredAmount,
    this.currentAmount = 0,
    required this.type,
    required this.rewardPoints,
    required this.expiresAt,
    this.isCompleted = false,
  });

  double get progress => currentAmount / requiredAmount;

  DailyChallenge copyWith({
    int? currentAmount,
    bool? isCompleted,
  }) {
    return DailyChallenge(
      id: id,
      title: title,
      description: description,
      requiredAmount: requiredAmount,
      currentAmount: currentAmount ?? this.currentAmount,
      type: type,
      rewardPoints: rewardPoints,
      expiresAt: expiresAt,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }
} 