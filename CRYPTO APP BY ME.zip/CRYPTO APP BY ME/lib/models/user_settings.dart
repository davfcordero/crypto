class UserSettings {
  final bool notificationsEnabled;
  final bool darkModeEnabled;
  final String preferredCurrency;
  final List<String> favoriteCoins;
  final bool soundEffectsEnabled;
  final bool vibrationEnabled;
  final Map<String, bool> notificationPreferences;

  UserSettings({
    this.notificationsEnabled = true,
    this.darkModeEnabled = true,
    this.preferredCurrency = 'USD',
    this.favoriteCoins = const ['BTC', 'ETH'],
    this.soundEffectsEnabled = true,
    this.vibrationEnabled = true,
    this.notificationPreferences = const {
      'predictions': true,
      'mining': true,
      'achievements': true,
      'priceAlerts': true,
    },
  });

  UserSettings copyWith({
    bool? notificationsEnabled,
    bool? darkModeEnabled,
    String? preferredCurrency,
    List<String>? favoriteCoins,
    bool? soundEffectsEnabled,
    bool? vibrationEnabled,
    Map<String, bool>? notificationPreferences,
  }) {
    return UserSettings(
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      darkModeEnabled: darkModeEnabled ?? this.darkModeEnabled,
      preferredCurrency: preferredCurrency ?? this.preferredCurrency,
      favoriteCoins: favoriteCoins ?? this.favoriteCoins,
      soundEffectsEnabled: soundEffectsEnabled ?? this.soundEffectsEnabled,
      vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
      notificationPreferences: notificationPreferences ?? this.notificationPreferences,
    );
  }
} 