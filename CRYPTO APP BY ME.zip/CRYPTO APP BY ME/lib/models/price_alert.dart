class PriceAlert {
  final String id;
  final String symbol;
  final double targetPrice;
  final bool isAbove; // true for above, false for below
  final bool isActive;
  final DateTime createdAt;

  PriceAlert({
    required this.id,
    required this.symbol,
    required this.targetPrice,
    required this.isAbove,
    this.isActive = true,
    required this.createdAt,
  });

  factory PriceAlert.fromJson(Map<String, dynamic> json) {
    return PriceAlert(
      id: json['id'],
      symbol: json['symbol'],
      targetPrice: json['target_price'],
      isAbove: json['is_above'],
      isActive: json['is_active'],
      createdAt: DateTime.parse(json['created_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'symbol': symbol,
      'target_price': targetPrice,
      'is_above': isAbove,
      'is_active': isActive,
      'created_at': createdAt.toIso8601String(),
    };
  }
} 