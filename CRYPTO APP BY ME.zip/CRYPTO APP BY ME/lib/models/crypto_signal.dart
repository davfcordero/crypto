class CryptoSignal {
  final String id;
  final String cryptocurrency;
  final String signal; // 'buy', 'sell', 'hold'
  final String prediction;
  final String explanation;
  final double confidence;
  final List<double> priceHistory;
  final DateTime timestamp;
  final bool? userDecision; // true for approved, false for rejected, null for pending

  CryptoSignal({
    required this.id,
    required this.cryptocurrency,
    required this.signal,
    required this.prediction,
    required this.explanation,
    required this.confidence,
    required this.priceHistory,
    required this.timestamp,
    this.userDecision,
  });

  factory CryptoSignal.fromJson(Map<String, dynamic> json) {
    return CryptoSignal(
      id: json['id'],
      cryptocurrency: json['cryptocurrency'],
      signal: json['signal'],
      prediction: json['prediction'],
      explanation: json['explanation'],
      confidence: json['confidence'].toDouble(),
      priceHistory: List<double>.from(json['price_history']),
      timestamp: DateTime.parse(json['timestamp']),
      userDecision: json['user_decision'],
    );
  }

  CryptoSignal copyWith({
    bool? userDecision,
  }) {
    return CryptoSignal(
      id: id,
      cryptocurrency: cryptocurrency,
      signal: signal,
      prediction: prediction,
      explanation: explanation,
      confidence: confidence,
      priceHistory: priceHistory,
      timestamp: timestamp,
      userDecision: userDecision ?? this.userDecision,
    );
  }
} 