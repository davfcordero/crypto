import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/achievement.dart';

final achievementsProvider = StateNotifierProvider<AchievementsNotifier, List<Achievement>>((ref) {
  return AchievementsNotifier();
});

class AchievementsNotifier extends StateNotifier<List<Achievement>> {
  AchievementsNotifier() : super([
    Achievement(
      id: 'first_prediction',
      title: 'Fortune Teller',
      description: 'Make your first prediction',
      icon: '🔮',
      points: 10,
      targetValue: 1,
    ),
    Achievement(
      id: 'mining_master',
      title: 'Mining Master',
      description: 'Reach 100 MH/s mining power',
      icon: '⛏️',
      points: 50,
      targetValue: 100,
    ),
    Achievement(
      id: 'daily_streak',
      title: 'Daily Oracle',
      description: 'Check predictions for 7 consecutive days',
      icon: '📅',
      points: 100,
      targetValue: 7,
    ),
    Achievement(
      id: 'accurate_predictions',
      title: 'Crystal Clear',
      description: 'Get 10 accurate predictions',
      icon: '🎯',
      points: 200,
      targetValue: 10,
    ),
  ]);

  void updateProgress(String achievementId, int value) {
    state = state.map((achievement) {
      if (achievement.id == achievementId) {
        final progress = value / achievement.targetValue;
        return Achievement(
          id: achievement.id,
          title: achievement.title,
          description: achievement.description,
          icon: achievement.icon,
          points: achievement.points,
          isUnlocked: progress >= 1.0,
          progress: progress.clamp(0.0, 1.0),
          targetValue: achievement.targetValue,
          currentValue: value,
        );
      }
      return achievement;
    }).toList();
  }
} 