import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/crypto_signal.dart';

final signalHistoryProvider = StateNotifierProvider<SignalHistoryNotifier, List<CryptoSignal>>((ref) {
  return SignalHistoryNotifier();
});

class SignalHistoryNotifier extends StateNotifier<List<CryptoSignal>> {
  SignalHistoryNotifier() : super([]);

  void addToHistory(CryptoSignal signal) {
    state = [signal, ...state];
  }

  void clearHistory() {
    state = [];
  }

  double getAccuracy() {
    final decidedSignals = state.where((s) => s.userDecision != null).toList();
    if (decidedSignals.isEmpty) return 0.0;

    final correctPredictions = decidedSignals.where((s) {
      final wasCorrect = s.userDecision! && s.signal == 'buy' ||
                        !s.userDecision! && s.signal == 'sell';
      return wasCorrect;
    }).length;

    return correctPredictions / decidedSignals.length;
  }
} 