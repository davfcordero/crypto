import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:async';
import 'package:crypto_tarot/models/mining_reward.dart';
import 'package:crypto_tarot/services/storage_service.dart';

final miningStatsProvider = StateNotifierProvider<MiningStatsNotifier, MiningStats>((ref) {
  final storage = ref.read(storageServiceProvider);
  return MiningStatsNotifier(storage);
});

class MiningStats {
  final double hashPower;
  final double earnings;
  final int level;
  final List<MiningReward> activeRewards;
  final DateTime lastBoostUsed;
  final double difficulty;
  final double efficiency;
  final int gpuCount;
  final bool isAutoMining;
  final double powerConsumption;
  final double dailyOperatingCost;

  MiningStats({
    this.hashPower = 50.0,
    this.earnings = 0.0,
    this.level = 1,
    this.activeRewards = const [],
    this.difficulty = 1.0,
    this.efficiency = 1.0,
    this.gpuCount = 1,
    this.isAutoMining = false,
    this.powerConsumption = 200.0,
    this.dailyOperatingCost = 5.0,
    DateTime? lastBoostUsed,
  }) : lastBoostUsed = lastBoostUsed ?? DateTime.now().subtract(const Duration(hours: 24));

  double get totalMultiplier {
    return activeRewards.fold(
      1.0,
      (total, reward) => total * (reward.isActive && !reward.isExpired ? reward.multiplier : 1.0),
    );
  }

  double get hourlyEarnings {
    return (hashPower * efficiency * totalMultiplier) / (difficulty * 100);
  }

  double get dailyProfit {
    return (hourlyEarnings * 24) - dailyOperatingCost;
  }

  MiningStats copyWith({
    double? hashPower,
    double? earnings,
    int? level,
    List<MiningReward>? activeRewards,
    DateTime? lastBoostUsed,
    double? difficulty,
    double? efficiency,
    int? gpuCount,
    bool? isAutoMining,
    double? powerConsumption,
    double? dailyOperatingCost,
  }) {
    return MiningStats(
      hashPower: hashPower ?? this.hashPower,
      earnings: earnings ?? this.earnings,
      level: level ?? this.level,
      activeRewards: activeRewards ?? this.activeRewards,
      lastBoostUsed: lastBoostUsed ?? this.lastBoostUsed,
      difficulty: difficulty ?? this.difficulty,
      efficiency: efficiency ?? this.efficiency,
      gpuCount: gpuCount ?? this.gpuCount,
      isAutoMining: isAutoMining ?? this.isAutoMining,
      powerConsumption: powerConsumption ?? this.powerConsumption,
      dailyOperatingCost: dailyOperatingCost ?? this.dailyOperatingCost,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'hashPower': hashPower,
      'earnings': earnings,
      'level': level,
      'difficulty': difficulty,
      'efficiency': efficiency,
      'gpuCount': gpuCount,
      'isAutoMining': isAutoMining,
      'powerConsumption': powerConsumption,
      'dailyOperatingCost': dailyOperatingCost,
      'lastBoostUsed': lastBoostUsed.toIso8601String(),
    };
  }

  factory MiningStats.fromJson(Map<String, dynamic> json) {
    return MiningStats(
      hashPower: json['hashPower'],
      earnings: json['earnings'],
      level: json['level'],
      difficulty: json['difficulty'],
      efficiency: json['efficiency'],
      gpuCount: json['gpuCount'],
      isAutoMining: json['isAutoMining'],
      powerConsumption: json['powerConsumption'],
      dailyOperatingCost: json['dailyOperatingCost'],
      lastBoostUsed: DateTime.parse(json['lastBoostUsed']),
    );
  }
}

class MiningStatsNotifier extends StateNotifier<MiningStats> {
  final StorageService _storage;
  Timer? _miningTimer;
  Timer? _autoSaveTimer;

  MiningStatsNotifier(this._storage) : super(MiningStats()) {
    _loadStats();
    _startAutoSave();
  }

  Future<void> _loadStats() async {
    final savedStats = _storage.getMiningStats();
    if (savedStats != null) {
      state = MiningStats.fromJson(savedStats);
      if (state.isAutoMining) {
        startMining();
      }
    }
  }

  void _startAutoSave() {
    _autoSaveTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      _storage.saveMiningStats(state.toJson());
    });
  }

  @override
  void dispose() {
    _miningTimer?.cancel();
    _autoSaveTimer?.cancel();
    super.dispose();
  }

  void startMining() {
    _miningTimer?.cancel();
    _miningTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      final earnings = state.hourlyEarnings / 3600; // Per second
      addEarnings(earnings);
    });
    state = state.copyWith(isAutoMining: true);
  }

  void stopMining() {
    _miningTimer?.cancel();
    state = state.copyWith(isAutoMining: false);
  }

  void toggleMining() {
    if (state.isAutoMining) {
      stopMining();
    } else {
      startMining();
    }
  }

  void updateHashPower(double power) {
    state = state.copyWith(hashPower: power);
  }

  void addGPU() {
    if (state.gpuCount < 8) { // Maximum 8 GPUs
      state = state.copyWith(
        gpuCount: state.gpuCount + 1,
        hashPower: state.hashPower + 50.0,
        powerConsumption: state.powerConsumption + 200.0,
        dailyOperatingCost: state.dailyOperatingCost + 5.0,
      );
    }
  }

  void removeGPU() {
    if (state.gpuCount > 1) { // Minimum 1 GPU
      state = state.copyWith(
        gpuCount: state.gpuCount - 1,
        hashPower: state.hashPower - 50.0,
        powerConsumption: state.powerConsumption - 200.0,
        dailyOperatingCost: state.dailyOperatingCost - 5.0,
      );
    }
  }

  void updateEfficiency(double efficiency) {
    state = state.copyWith(efficiency: efficiency.clamp(0.1, 1.0));
  }

  void addEarnings(double amount) {
    final multipliedAmount = amount * state.totalMultiplier;
    state = state.copyWith(earnings: state.earnings + multipliedAmount);
  }

  void activateBoost() {
    if (_canUseBoost()) {
      final boost = MiningReward(
        id: 'boost_${DateTime.now().millisecondsSinceEpoch}',
        title: '2x Mining Boost',
        description: 'Double mining rewards for 1 hour',
        multiplier: 2.0,
        duration: const Duration(hours: 1),
        expiresAt: DateTime.now().add(const Duration(hours: 1)),
      );

      state = state.copyWith(
        activeRewards: [...state.activeRewards, boost],
        lastBoostUsed: DateTime.now(),
      );
    }
  }

  bool _canUseBoost() {
    return DateTime.now().difference(state.lastBoostUsed) >= const Duration(hours: 4);
  }

  Duration timeUntilNextBoost() {
    final timeSinceLastBoost = DateTime.now().difference(state.lastBoostUsed);
    final cooldown = const Duration(hours: 4);
    return timeSinceLastBoost >= cooldown ? Duration.zero : cooldown - timeSinceLastBoost;
  }
} 