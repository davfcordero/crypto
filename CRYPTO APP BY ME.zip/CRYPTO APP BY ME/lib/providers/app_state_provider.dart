import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/services/storage_service.dart';

final appStateProvider = StateNotifierProvider<AppStateNotifier, AppState>((ref) {
  return AppStateNotifier(ref.read(storageServiceProvider));
});

enum AppStatus {
  initializing,
  ready,
  error,
}

class AppState {
  final AppStatus status;
  final String? error;
  final bool isFirstLaunch;

  AppState({
    this.status = AppStatus.initializing,
    this.error,
    this.isFirstLaunch = true,
  });

  AppState copyWith({
    AppStatus? status,
    String? error,
    bool? isFirstLaunch,
  }) {
    return AppState(
      status: status ?? this.status,
      error: error ?? this.error,
      isFirstLaunch: isFirstLaunch ?? this.isFirstLaunch,
    );
  }
}

class AppStateNotifier extends StateNotifier<AppState> {
  final StorageService _storageService;

  AppStateNotifier(this._storageService) : super(AppState()) {
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      // Load saved settings
      final settings = _storageService.getSettings();
      final isFirstLaunch = settings == null;

      // Load other necessary data
      await Future.wait([
        _loadSignalHistory(),
        _loadMiningStats(),
      ]);

      state = state.copyWith(
        status: AppStatus.ready,
        isFirstLaunch: isFirstLaunch,
      );
    } catch (e) {
      state = state.copyWith(
        status: AppStatus.error,
        error: 'Failed to initialize app: $e',
      );
    }
  }

  Future<void> _loadSignalHistory() async {
    final history = _storageService.getSignalHistory();
    // Initialize signal history provider
  }

  Future<void> _loadMiningStats() async {
    final stats = _storageService.getMiningStats();
    // Initialize mining stats provider
  }
} 