import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/daily_challenge.dart';

final challengesProvider = StateNotifierProvider<ChallengesNotifier, List<DailyChallenge>>((ref) {
  return ChallengesNotifier();
});

class ChallengesNotifier extends StateNotifier<List<DailyChallenge>> {
  ChallengesNotifier() : super([]) {
    _generateDailyChallenges();
  }

  void _generateDailyChallenges() {
    final tomorrow = DateTime.now().add(const Duration(days: 1));
    final expiresAt = DateTime(tomorrow.year, tomorrow.month, tomorrow.day);

    state = [
      DailyChallenge(
        id: 'daily_mining_1',
        title: 'Mining Master',
        description: 'Mine for 30 minutes today',
        requiredAmount: 30,
        type: 'mining',
        rewardPoints: 50,
        expiresAt: expiresAt,
      ),
      DailyChallenge(
        id: 'daily_predictions_1',
        title: 'Crypto Oracle',
        description: 'Make 5 predictions',
        requiredAmount: 5,
        type: 'prediction',
        rewardPoints: 100,
        expiresAt: expiresAt,
      ),
      DailyChallenge(
        id: 'daily_streak_1',
        title: 'Consistency is Key',
        description: 'Maintain your daily streak',
        requiredAmount: 1,
        type: 'streak',
        rewardPoints: 75,
        expiresAt: expiresAt,
      ),
    ];
  }

  void updateProgress(String challengeId, int amount) {
    state = state.map((challenge) {
      if (challenge.id == challengeId && !challenge.isCompleted) {
        final newAmount = challenge.currentAmount + amount;
        final isCompleted = newAmount >= challenge.requiredAmount;
        
        return challenge.copyWith(
          currentAmount: newAmount,
          isCompleted: isCompleted,
        );
      }
      return challenge;
    }).toList();
  }

  void resetDailyChallenges() {
    _generateDailyChallenges();
  }
} 