import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/user_settings.dart';

final settingsProvider = StateNotifierProvider<SettingsNotifier, UserSettings>((ref) {
  return SettingsNotifier();
});

class SettingsNotifier extends StateNotifier<UserSettings> {
  SettingsNotifier() : super(UserSettings());

  void toggleNotifications(bool enabled) {
    state = state.copyWith(notificationsEnabled: enabled);
  }

  void toggleDarkMode(bool enabled) {
    state = state.copyWith(darkModeEnabled: enabled);
  }

  void setPreferredCurrency(String currency) {
    state = state.copyWith(preferredCurrency: currency);
  }

  void toggleFavoriteCoin(String coin) {
    final favorites = List<String>.from(state.favoriteCoins);
    if (favorites.contains(coin)) {
      favorites.remove(coin);
    } else {
      favorites.add(coin);
    }
    state = state.copyWith(favoriteCoins: favorites);
  }

  void toggleSoundEffects(bool enabled) {
    state = state.copyWith(soundEffectsEnabled: enabled);
  }

  void toggleVibration(bool enabled) {
    state = state.copyWith(vibrationEnabled: enabled);
  }

  void updateNotificationPreference(String type, bool enabled) {
    final preferences = Map<String, bool>.from(state.notificationPreferences);
    preferences[type] = enabled;
    state = state.copyWith(notificationPreferences: preferences);
  }
} 