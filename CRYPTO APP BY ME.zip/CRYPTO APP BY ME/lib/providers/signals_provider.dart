import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/crypto_signal.dart';
import 'package:crypto_tarot/services/signal_generator.dart';
import 'package:crypto_tarot/services/crypto_service.dart';

final signalsProvider = StateNotifierProvider<SignalsNotifier, List<CryptoSignal>>((ref) {
  final signalGenerator = ref.read(signalGeneratorProvider);
  final cryptoService = ref.read(cryptoServiceProvider);
  return SignalsNotifier(signalGenerator, cryptoService);
});

class SignalsNotifier extends StateNotifier<List<CryptoSignal>> {
  final SignalGenerator _signalGenerator;
  final CryptoService _cryptoService;

  SignalsNotifier(this._signalGenerator, this._cryptoService) : super([]) {
    generateSignals();
  }

  Future<void> generateSignals() async {
    try {
      final marketData = await _cryptoService.getTopCryptos(limit: 5);
      final signals = await Future.wait(
        marketData.map((data) => _signalGenerator.generateSignal(data)),
      );
      
      state = signals;
    } catch (e) {
      // Handle error
      print('Error generating signals: $e');
    }
  }

  void updateSignal(String id, bool approved) {
    state = [
      for (final signal in state)
        if (signal.id == id)
          signal.copyWith(userDecision: approved)
        else
          signal,
    ];
  }

  void removeSignal(String id) {
    state = state.where((signal) => signal.id != id).toList();
  }
} 