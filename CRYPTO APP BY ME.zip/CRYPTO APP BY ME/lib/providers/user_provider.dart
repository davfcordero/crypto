import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/user_profile.dart';

final userProvider = StateNotifierProvider<UserNotifier, UserProfile>((ref) {
  return UserNotifier();
});

class UserNotifier extends StateNotifier<UserProfile> {
  UserNotifier()
      : super(UserProfile(
          id: 'user_1',
          username: 'CryptoOracle',
          avatarUrl: 'assets/images/default_avatar.png',
          level: 1,
          totalPoints: 0,
          predictionAccuracy: 0,
          totalEarnings: 0.0,
          dailyStreak: 0,
          achievements: [],
          joinedDate: DateTime.now(),
        ));

  void addPoints(int points) {
    state = state.copyWith(
      totalPoints: state.totalPoints + points,
      level: _calculateLevel(state.totalPoints + points),
    );
  }

  void updatePredictionAccuracy(bool wasCorrect) {
    final totalPredictions = state.achievements.length;
    final correctPredictions = wasCorrect
        ? state.predictionAccuracy * totalPredictions + 1
        : state.predictionAccuracy * totalPredictions;
    
    state = state.copyWith(
      predictionAccuracy: ((correctPredictions / (totalPredictions + 1)) * 100).round(),
    );
  }

  void addEarnings(double amount) {
    state = state.copyWith(totalEarnings: state.totalEarnings + amount);
  }

  void incrementStreak() {
    state = state.copyWith(dailyStreak: state.dailyStreak + 1);
  }

  void resetStreak() {
    state = state.copyWith(dailyStreak: 0);
  }

  void unlockAchievement(String achievementId) {
    if (!state.achievements.contains(achievementId)) {
      state = state.copyWith(
        achievements: [...state.achievements, achievementId],
      );
    }
  }

  int _calculateLevel(int points) {
    return (points / 1000).floor() + 1;
  }

  void updateProfile({String? username, String? avatarUrl}) {
    state = UserProfile(
      id: state.id,
      username: username ?? state.username,
      avatarUrl: avatarUrl ?? state.avatarUrl,
      level: state.level,
      totalPoints: state.totalPoints,
      predictionAccuracy: state.predictionAccuracy,
      totalEarnings: state.totalEarnings,
      dailyStreak: state.dailyStreak,
      achievements: state.achievements,
      joinedDate: state.joinedDate,
    );
  }
} 