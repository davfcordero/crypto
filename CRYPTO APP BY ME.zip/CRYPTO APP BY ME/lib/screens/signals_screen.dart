import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/providers/signals_provider.dart';
import 'package:crypto_tarot/providers/signal_history_provider.dart';
import 'package:crypto_tarot/widgets/signal_card.dart';
import 'package:crypto_tarot/widgets/loading_indicator.dart';
import 'package:crypto_tarot/widgets/error_view.dart';
import 'package:crypto_tarot/screens/signal_details_screen.dart';

class SignalsScreen extends ConsumerStatefulWidget {
  const SignalsScreen({super.key});

  @override
  ConsumerState<SignalsScreen> createState() => _SignalsScreenState();
}

class _SignalsScreenState extends ConsumerState<SignalsScreen> {
  @override
  void initState() {
    super.initState();
    _loadSignals();
  }

  Future<void> _loadSignals() async {
    ref.read(signalsProvider.notifier).generateSignals();
  }

  @override
  Widget build(BuildContext context) {
    final signals = ref.watch(signalsProvider);

    return RefreshIndicator(
      onRefresh: _loadSignals,
      child: signals.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.auto_awesome, size: 48),
                  const SizedBox(height: 16),
                  Text(
                    'No signals available',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: _loadSignals,
                    child: const Text('Generate Signals'),
                  ),
                ],
              ),
            )
          : Stack(
              alignment: Alignment.center,
              children: [
                for (var i = 0; i < signals.length; i++)
                  if (i < 3)
                    Positioned(
                      top: 32.0 * (2 - i),
                      child: Transform.scale(
                        scale: 1.0 - (0.05 * i),
                        child: IgnorePointer(
                          ignoring: i != 0,
                          child: Opacity(
                            opacity: 1.0 - (0.2 * i),
                            child: SignalCard(
                              signal: signals[i],
                              onSwipe: (approved) {
                                // Add to history
                                ref.read(signalHistoryProvider.notifier).addToHistory(
                                      signals[i].copyWith(userDecision: approved),
                                    );
                                
                                // Update and remove from current signals
                                ref.read(signalsProvider.notifier)
                                  ..updateSignal(signals[i].id, approved)
                                  ..removeSignal(signals[i].id);
                              },
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => SignalDetailsScreen(
                                      signal: signals[i],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
              ],
            ),
    );
  }
} 