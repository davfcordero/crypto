import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:crypto_tarot/models/market_data.dart';
import 'package:crypto_tarot/widgets/technical_indicators.dart';
import 'package:crypto_tarot/widgets/price_alerts.dart';

class DetailScreen extends StatefulWidget {
  final MarketData marketData;
  final String prediction;

  const DetailScreen({
    super.key,
    required this.marketData,
    required this.prediction,
  });

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _showVolume = false;
  String _timeframe = '1D';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text(widget.marketData.symbol.toUpperCase()),
            const SizedBox(width: 8),
            Text(
              '\$${widget.marketData.currentPrice.toStringAsFixed(2)}',
              style: TextStyle(
                color: widget.marketData.priceChangePercentage24h >= 0
                    ? Colors.green
                    : Colors.red,
              ),
            ),
          ],
        ),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Chart'),
            Tab(text: 'Analysis'),
            Tab(text: 'Alerts'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildChartTab(),
          TechnicalIndicators(marketData: widget.marketData),
          PriceAlerts(symbol: widget.marketData.symbol),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showPredictionDialog(),
        label: const Text('AI Prediction'),
        icon: const Icon(Icons.auto_awesome),
      ),
    );
  }

  Widget _buildChartTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: '1D', label: Text('1D')),
                  ButtonSegment(value: '1W', label: Text('1W')),
                  ButtonSegment(value: '1M', label: Text('1M')),
                  ButtonSegment(value: '1Y', label: Text('1Y')),
                ],
                selected: {_timeframe},
                onSelectionChanged: (Set<String> selection) {
                  setState(() => _timeframe = selection.first);
                },
              ),
              Switch(
                value: _showVolume,
                onChanged: (value) => setState(() => _showVolume = value),
                label: const Text('Volume'),
              ),
            ],
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: LineChart(
              LineChartData(
                gridData: const FlGridData(show: true),
                titlesData: const FlTitlesData(show: true),
                borderData: FlBorderData(show: true),
                lineBarsData: [
                  LineChartBarData(
                    spots: widget.marketData.priceHistory.asMap().entries.map((entry) {
                      return FlSpot(entry.key.toDouble(), entry.value);
                    }).toList(),
                    isCurved: true,
                    color: Theme.of(context).colorScheme.primary,
                    barWidth: 3,
                    dotData: const FlDotData(show: false),
                    belowBarData: BarAreaData(
                      show: true,
                      color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showPredictionDialog() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.auto_awesome, size: 48),
            const SizedBox(height: 16),
            Text(
              'AI Prediction',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              widget.prediction,
              style: Theme.of(context).textTheme.bodyLarge,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
} 