import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/providers/mining_provider.dart';
import 'package:crypto_tarot/widgets/mining/mining_progress_card.dart';
import 'package:crypto_tarot/widgets/mining/gpu_management_card.dart';
import 'package:crypto_tarot/widgets/mining/mining_stats_card.dart';

class MiningSimulatorScreen extends ConsumerWidget {
  const MiningSimulatorScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final miningStats = ref.watch(miningStatsProvider);
    final notifier = ref.read(miningStatsProvider.notifier);

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            MiningProgressCard(
              stats: miningStats,
              onToggleMining: () => notifier.toggleMining(),
            ),
            const SizedBox(height: 16),
            GPUManagementCard(
              gpuCount: miningStats.gpuCount,
              onAddGPU: () => notifier.addGPU(),
              onRemoveGPU: () => notifier.removeGPU(),
              efficiency: miningStats.efficiency,
              onUpdateEfficiency: (value) => notifier.updateEfficiency(value),
            ),
            const SizedBox(height: 16),
            MiningStatsCard(stats: miningStats),
            if (miningStats.activeRewards.isNotEmpty) ...[
              const SizedBox(height: 16),
              _buildActiveRewardsCard(context, miningStats),
            ],
          ],
        ),
      ),
      floatingActionButton: _buildBoostButton(context, ref),
    );
  }

  Widget _buildActiveRewardsCard(BuildContext context, MiningStats stats) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Active Boosts',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            ...stats.activeRewards
                .where((reward) => !reward.isExpired)
                .map((reward) => ListTile(
                      leading: const Icon(Icons.rocket_launch),
                      title: Text(reward.title),
                      subtitle: Text(reward.description),
                      trailing: Text('${reward.multiplier}x'),
                    )),
          ],
        ),
      ),
    );
  }

  Widget _buildBoostButton(BuildContext context, WidgetRef ref) {
    final timeUntilNextBoost = ref
        .read(miningStatsProvider.notifier)
        .timeUntilNextBoost();

    if (timeUntilNextBoost.inSeconds > 0) {
      final minutes = timeUntilNextBoost.inMinutes;
      final seconds = timeUntilNextBoost.inSeconds % 60;
      return FloatingActionButton.extended(
        onPressed: null,
        icon: const Icon(Icons.timer),
        label: Text('$minutes:${seconds.toString().padLeft(2, '0')}'),
      );
    }

    return FloatingActionButton.extended(
      onPressed: () {
        ref.read(miningStatsProvider.notifier).activateBoost();
      },
      icon: const Icon(Icons.rocket_launch),
      label: const Text('Activate Boost'),
    );
  }
} 