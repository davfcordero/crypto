import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:crypto_tarot/providers/mining_provider.dart';
import 'package:crypto_tarot/providers/signals_provider.dart';

class AnalyticsScreen extends ConsumerWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final miningStats = ref.watch(miningStatsProvider);
    final signals = ref.watch(signalsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildMiningSection(context, miningStats),
          const SizedBox(height: 24),
          _buildPredictionsSection(context, signals),
          const SizedBox(height: 24),
          _buildEarningsChart(context, miningStats),
        ],
      ),
    );
  }

  Widget _buildMiningSection(BuildContext context, MiningStats stats) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Mining Performance',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatCard(
                  context,
                  'Hash Power',
                  '${stats.hashPower.toStringAsFixed(1)} MH/s',
                  Icons.memory,
                ),
                _buildStatCard(
                  context,
                  'Level',
                  'Level ${stats.level}',
                  Icons.trending_up,
                ),
                _buildStatCard(
                  context,
                  'Multiplier',
                  '${stats.totalMultiplier.toStringAsFixed(1)}x',
                  Icons.star,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(
    BuildContext context,
    String label,
    String value,
    IconData icon,
  ) {
    return Column(
      children: [
        Icon(icon, size: 32, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 8),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
        Text(
          value,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
      ],
    );
  }

  Widget _buildPredictionsSection(BuildContext context, AsyncValue<List<dynamic>> signals) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Prediction Accuracy',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: PieChart(
                PieChartData(
                  sections: [
                    PieChartSectionData(
                      value: 65,
                      title: '65%',
                      color: Colors.green,
                      radius: 80,
                    ),
                    PieChartSectionData(
                      value: 35,
                      title: '35%',
                      color: Colors.red,
                      radius: 75,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildLegendItem('Accurate', Colors.green),
                SizedBox(width: 24),
                _buildLegendItem('Inaccurate', Colors.red),
              ],
            ),
          ],
        ),
      ),
    );
  }

  static const _buildLegendItem = _LegendItem.new;
}

class _LegendItem extends StatelessWidget {
  final String label;
  final Color color;

  const _LegendItem(this.label, this.color);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 8),
        Text(label),
      ],
    );
  }
} 