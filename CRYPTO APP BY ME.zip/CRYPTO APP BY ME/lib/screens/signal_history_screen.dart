import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/providers/signal_history_provider.dart';
import 'package:crypto_tarot/screens/signal_details_screen.dart';
import 'package:timeago/timeago.dart' as timeago;

class SignalHistoryScreen extends ConsumerWidget {
  const SignalHistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(signalHistoryProvider);
    final accuracy = ref.read(signalHistoryProvider.notifier).getAccuracy();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Signal History'),
      ),
      body: Column(
        children: [
          _buildAccuracyHeader(context, accuracy),
          Expanded(
            child: history.isEmpty
                ? const Center(
                    child: Text('No signal history yet'),
                  )
                : ListView.builder(
                    itemCount: history.length,
                    itemBuilder: (context, index) {
                      final signal = history[index];
                      return ListTile(
                        leading: Icon(
                          signal.userDecision == true
                              ? Icons.thumb_up
                              : Icons.thumb_down,
                          color: signal.userDecision == true
                              ? Colors.green
                              : Colors.red,
                        ),
                        title: Text(
                          '${signal.cryptocurrency} - ${signal.signal.toUpperCase()}',
                        ),
                        subtitle: Text(
                          timeago.format(signal.timestamp),
                        ),
                        trailing: Text(
                          '${(signal.confidence * 100).toInt()}%',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                color: Theme.of(context).colorScheme.primary,
                              ),
                        ),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SignalDetailsScreen(
                                signal: signal,
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildAccuracyHeader(BuildContext context, double accuracy) {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Theme.of(context).colorScheme.primaryContainer,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.analytics),
          const SizedBox(width: 8),
          Text(
            'Prediction Accuracy: ${(accuracy * 100).toInt()}%',
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ],
      ),
    );
  }
} 