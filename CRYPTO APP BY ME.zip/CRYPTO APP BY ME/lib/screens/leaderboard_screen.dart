import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class LeaderboardScreen extends ConsumerWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Leaderboard'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Points'),
              Tab(text: 'Predictions'),
              Tab(text: 'Mining'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildLeaderboardTab(context, 'points'),
            _buildLeaderboardTab(context, 'predictions'),
            _buildLeaderboardTab(context, 'mining'),
          ],
        ),
      ),
    );
  }

  Widget _buildLeaderboardTab(BuildContext context, String type) {
    // In a real app, this would fetch data from a backend
    final items = List.generate(
      20,
      (index) => _LeaderboardItem(
        rank: index + 1,
        username: 'User${index + 1}',
        score: (1000 - index * 50).toString(),
        type: type,
      ),
    );

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: items.length,
      itemBuilder: (context, index) {
        return _buildLeaderboardCard(context, items[index]);
      },
    );
  }

  Widget _buildLeaderboardCard(BuildContext context, _LeaderboardItem item) {
    final theme = Theme.of(context);
    final isTopThree = item.rank <= 3;
    final rankColor = isTopThree
        ? [Colors.amber, Colors.grey[300], Colors.brown][item.rank - 1]
        : null;

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: rankColor ?? theme.colorScheme.surface,
          child: Text(
            '#${item.rank}',
            style: TextStyle(
              color: rankColor != null ? Colors.black : null,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        title: Text(item.username),
        trailing: Text(
          item.score,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

class _LeaderboardItem {
  final int rank;
  final String username;
  final String score;
  final String type;

  _LeaderboardItem({
    required this.rank,
    required this.username,
    required this.score,
    required this.type,
  });
} 