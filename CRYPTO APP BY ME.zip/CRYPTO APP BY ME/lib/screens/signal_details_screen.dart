import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:crypto_tarot/models/crypto_signal.dart';
import 'package:crypto_tarot/widgets/technical_indicator_card.dart';
import 'package:crypto_tarot/widgets/prediction_explanation_card.dart';

class SignalDetailsScreen extends StatelessWidget {
  final CryptoSignal signal;

  const SignalDetailsScreen({
    super.key,
    required this.signal,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('${signal.cryptocurrency} Analysis'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSignalHeader(theme),
            const SizedBox(height: 24),
            _buildPriceChart(theme),
            const SizedBox(height: 24),
            _buildTechnicalAnalysis(theme),
            const SizedBox(height: 24),
            _buildAIPrediction(theme),
          ],
        ),
      ),
    );
  }

  Widget _buildSignalHeader(ThemeData theme) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: _getSignalColor(signal.signal).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    signal.signal.toUpperCase(),
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: _getSignalColor(signal.signal),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Confidence',
                      style: theme.textTheme.bodySmall,
                    ),
                    Text(
                      '${(signal.confidence * 100).toInt()}%',
                      style: theme.textTheme.titleLarge?.copyWith(
                        color: theme.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPriceChart(ThemeData theme) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Price History',
              style: theme.textTheme.titleMedium,
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: true,
                    horizontalInterval: 1,
                    verticalInterval: 1,
                    getDrawingHorizontalLine: (value) {
                      return FlLine(
                        color: theme.dividerColor,
                        strokeWidth: 1,
                      );
                    },
                    getDrawingVerticalLine: (value) {
                      return FlLine(
                        color: theme.dividerColor,
                        strokeWidth: 1,
                      );
                    },
                  ),
                  titlesData: FlTitlesData(
                    show: true,
                    rightTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    topTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),
                  borderData: FlBorderData(
                    show: true,
                    border: Border.all(color: theme.dividerColor),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: signal.priceHistory.asMap().entries.map((entry) {
                        return FlSpot(entry.key.toDouble(), entry.value);
                      }).toList(),
                      isCurved: true,
                      color: theme.colorScheme.primary,
                      barWidth: 3,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                        show: true,
                        color: theme.colorScheme.primary.withOpacity(0.1),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTechnicalAnalysis(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Technical Analysis',
          style: theme.textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 16,
          runSpacing: 16,
          children: const [
            TechnicalIndicatorCard(
              title: 'RSI',
              value: '65',
              interpretation: 'Slightly overbought',
            ),
            TechnicalIndicatorCard(
              title: 'MACD',
              value: 'Bullish',
              interpretation: 'Strong upward momentum',
            ),
            TechnicalIndicatorCard(
              title: 'Moving Averages',
              value: 'Crossover',
              interpretation: 'Golden cross forming',
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildAIPrediction(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'AI Prediction',
          style: theme.textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        PredictionExplanationCard(
          prediction: signal.prediction,
          explanation: signal.explanation,
          confidence: signal.confidence,
        ),
      ],
    );
  }

  Color _getSignalColor(String signal) {
    switch (signal.toLowerCase()) {
      case 'buy':
        return Colors.green;
      case 'sell':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }
} 