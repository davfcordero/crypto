import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/providers/settings_provider.dart';
import 'package:crypto_tarot/providers/user_provider.dart';
import 'package:crypto_tarot/screens/edit_profile_screen.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final user = ref.watch(userProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          _buildUserSection(context, user),
          const Divider(),
          _buildSettingsSection(
            context,
            'General',
            [
              SwitchListTile(
                title: const Text('Dark Mode'),
                subtitle: const Text('Enable dark theme'),
                value: settings.darkModeEnabled,
                onChanged: (value) {
                  ref.read(settingsProvider.notifier).toggleDarkMode(value);
                },
              ),
              ListTile(
                title: const Text('Preferred Currency'),
                subtitle: Text(settings.preferredCurrency),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showCurrencyPicker(context, ref),
              ),
            ],
          ),
          _buildSettingsSection(
            context,
            'Notifications',
            [
              SwitchListTile(
                title: const Text('Enable Notifications'),
                value: settings.notificationsEnabled,
                onChanged: (value) {
                  ref.read(settingsProvider.notifier).toggleNotifications(value);
                },
              ),
              if (settings.notificationsEnabled) ...[
                CheckboxListTile(
                  title: const Text('Predictions'),
                  value: settings.notificationPreferences['predictions'],
                  onChanged: (value) {
                    ref.read(settingsProvider.notifier)
                        .updateNotificationPreference('predictions', value ?? false);
                  },
                ),
                CheckboxListTile(
                  title: const Text('Mining Updates'),
                  value: settings.notificationPreferences['mining'],
                  onChanged: (value) {
                    ref.read(settingsProvider.notifier)
                        .updateNotificationPreference('mining', value ?? false);
                  },
                ),
                CheckboxListTile(
                  title: const Text('Achievements'),
                  value: settings.notificationPreferences['achievements'],
                  onChanged: (value) {
                    ref.read(settingsProvider.notifier)
                        .updateNotificationPreference('achievements', value ?? false);
                  },
                ),
                CheckboxListTile(
                  title: const Text('Price Alerts'),
                  value: settings.notificationPreferences['priceAlerts'],
                  onChanged: (value) {
                    ref.read(settingsProvider.notifier)
                        .updateNotificationPreference('priceAlerts', value ?? false);
                  },
                ),
              ],
            ],
          ),
          _buildSettingsSection(
            context,
            'App Feedback',
            [
              SwitchListTile(
                title: const Text('Sound Effects'),
                value: settings.soundEffectsEnabled,
                onChanged: (value) {
                  ref.read(settingsProvider.notifier).toggleSoundEffects(value);
                },
              ),
              SwitchListTile(
                title: const Text('Vibration'),
                value: settings.vibrationEnabled,
                onChanged: (value) {
                  ref.read(settingsProvider.notifier).toggleVibration(value);
                },
              ),
            ],
          ),
          _buildSettingsSection(
            context,
            'Favorite Cryptocurrencies',
            [
              Wrap(
                spacing: 8,
                children: [
                  'BTC',
                  'ETH',
                  'BNB',
                  'ADA',
                  'SOL',
                  'DOT',
                ].map((coin) {
                  final isFavorite = settings.favoriteCoins.contains(coin);
                  return FilterChip(
                    label: Text(coin),
                    selected: isFavorite,
                    onSelected: (selected) {
                      ref.read(settingsProvider.notifier).toggleFavoriteCoin(coin);
                    },
                  );
                }).toList(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextButton(
              onPressed: () {
                // Implement sign out functionality
              },
              child: const Text('Sign Out'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserSection(BuildContext context, UserProfile user) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundImage: AssetImage(user.avatarUrl),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user.username,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text(
                  'Member since ${_formatDate(user.joinedDate)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const EditProfileScreen(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsSection(
    BuildContext context,
    String title,
    List<Widget> children,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                ),
          ),
        ),
        ...children,
      ],
    );
  }

  String _formatDate(DateTime date) {
    return '${date.month}/${date.year}';
  }

  void _showCurrencyPicker(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return ListView(
          children: [
            'USD',
            'EUR',
            'GBP',
            'JPY',
            'AUD',
          ].map((currency) {
            return ListTile(
              title: Text(currency),
              onTap: () {
                ref.read(settingsProvider.notifier).setPreferredCurrency(currency);
                Navigator.pop(context);
              },
            );
          }).toList(),
        );
      },
    );
  }
} 