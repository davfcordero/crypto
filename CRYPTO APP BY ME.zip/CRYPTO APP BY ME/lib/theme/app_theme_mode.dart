import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/providers/settings_provider.dart';

final themeProvider = Provider<ThemeData>((ref) {
  final settings = ref.watch(settingsProvider);
  return settings.darkModeEnabled ? AppTheme.darkTheme : AppTheme.lightTheme;
});

class AppTheme {
  static final darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: ColorScheme.dark(
      primary: const Color(0xFF6B4EFF),
      secondary: const Color(0xFFFF4E8E),
      background: const Color(0xFF1A1A2E),
      surface: const Color(0xFF252547),
      error: Colors.red.shade400,
    ),
    scaffoldBackgroundColor: const Color(0xFF1A1A2E),
    cardTheme: CardTheme(
      color: const Color(0xFF252547),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
    ),
  );

  static final lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: ColorScheme.light(
      primary: const Color(0xFF6B4EFF),
      secondary: const Color(0xFFFF4E8E),
      background: Colors.grey.shade100,
      surface: Colors.white,
      error: Colors.red.shade600,
    ),
    scaffoldBackgroundColor: Colors.grey.shade100,
    cardTheme: CardTheme(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
    ),
  );
} 