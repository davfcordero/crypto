import 'package:flutter/material.dart';
import 'package:crypto_tarot/models/market_data.dart';

class TechnicalIndicators extends StatelessWidget {
  final MarketData marketData;

  const TechnicalIndicators({
    super.key,
    required this.marketData,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildIndicatorCard(
          context,
          title: 'Moving Averages',
          children: [
            _buildIndicatorRow('MA (20)', '⬆️ Bullish', Colors.green),
            _buildIndicatorRow('MA (50)', '⬆️ Bullish', Colors.green),
            _buildIndicatorRow('MA (200)', '➡️ Neutral', Colors.orange),
          ],
        ),
        const SizedBox(height: 16),
        _buildIndicatorCard(
          context,
          title: 'Oscillators',
          children: [
            _buildIndicatorRow('RSI (14)', '65.5', Colors.green),
            _buildIndicatorRow('MACD', 'Crossover', Colors.green),
            _buildIndicatorRow('Stochastic', 'Overbought', Colors.red),
          ],
        ),
        const SizedBox(height: 16),
        _buildIndicatorCard(
          context,
          title: 'Pivot Points',
          children: [
            _buildPivotPoint('R1', 45200.0),
            _buildPivotPoint('Pivot', 44800.0),
            _buildPivotPoint('S1', 44400.0),
          ],
        ),
        const SizedBox(height: 16),
        _buildSentimentIndicator(context),
      ],
    );
  }

  Widget _buildIndicatorCard(
    BuildContext context, {
    required String title,
    required List<Widget> children,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildIndicatorRow(String label, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPivotPoint(String label, double value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            '\$${value.toStringAsFixed(2)}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildSentimentIndicator(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Market Sentiment',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            const LinearProgressIndicator(
              value: 0.7,
              backgroundColor: Colors.red,
              color: Colors.green,
            ),
            const SizedBox(height: 8),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Bearish'),
                Text(
                  '70% Bullish',
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text('Bullish'),
              ],
            ),
          ],
        ),
      ),
    );
  }
} 