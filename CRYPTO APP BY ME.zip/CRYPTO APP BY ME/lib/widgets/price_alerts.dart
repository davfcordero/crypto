import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/models/price_alert.dart';
import 'package:crypto_tarot/providers/alerts_provider.dart';

class PriceAlerts extends ConsumerStatefulWidget {
  final String symbol;

  const PriceAlerts({
    super.key,
    required this.symbol,
  });

  @override
  ConsumerState<PriceAlerts> createState() => _PriceAlertsState();
}

class _PriceAlertsState extends ConsumerState<PriceAlerts> {
  final _priceController = TextEditingController();
  bool _isAbove = true;

  @override
  void dispose() {
    _priceController.dispose();
    super.dispose();
  }

  void _showAddAlertDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Price Alert'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _priceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Target Price',
                prefixText: '\$',
              ),
            ),
            const SizedBox(height: 16),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(
                  value: true,
                  label: Text('Above'),
                  icon: Icon(Icons.arrow_upward),
                ),
                ButtonSegment(
                  value: false,
                  label: Text('Below'),
                  icon: Icon(Icons.arrow_downward),
                ),
              ],
              selected: {_isAbove},
              onSelectionChanged: (Set<bool> selected) {
                setState(() => _isAbove = selected.first);
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final price = double.tryParse(_priceController.text);
              if (price != null) {
                ref.read(alertsProvider.notifier).addAlert(
                      symbol: widget.symbol,
                      targetPrice: price,
                      isAbove: _isAbove,
                    );
                Navigator.pop(context);
              }
            },
            child: const Text('Add Alert'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final alerts = ref.watch(alertsProvider)
        .where((alert) => alert.symbol == widget.symbol)
        .toList();

    return Stack(
      children: [
        alerts.isEmpty
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.notifications_none, size: 48),
                    const SizedBox(height: 16),
                    Text(
                      'No price alerts set',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: _showAddAlertDialog,
                      icon: const Icon(Icons.add),
                      label: const Text('Add Alert'),
                    ),
                  ],
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: alerts.length,
                itemBuilder: (context, index) {
                  final alert = alerts[index];
                  return _buildAlertCard(alert);
                },
              ),
        if (alerts.isNotEmpty)
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton(
              onPressed: _showAddAlertDialog,
              child: const Icon(Icons.add),
            ),
          ),
      ],
    );
  }

  Widget _buildAlertCard(PriceAlert alert) {
    return Dismissible(
      key: Key(alert.id),
      onDismissed: (_) {
        ref.read(alertsProvider.notifier).removeAlert(alert.id);
      },
      child: Card(
        margin: const EdgeInsets.only(bottom: 16),
        child: SwitchListTile(
          title: Text(
            '${alert.isAbove ? 'Above' : 'Below'} \$${alert.targetPrice}',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          subtitle: Text(
            'Created ${_formatDate(alert.createdAt)}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          value: alert.isActive,
          onChanged: (value) {
            ref.read(alertsProvider.notifier).toggleAlert(alert.id);
          },
          secondary: Icon(
            alert.isAbove ? Icons.arrow_upward : Icons.arrow_downward,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }
} 