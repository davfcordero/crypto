import 'package:flutter/material.dart';

enum SwipeDirection { left, right, none }

class SwipeableCard extends StatefulWidget {
  final Widget child;
  final Function(SwipeDirection) onSwipe;
  final VoidCallback? onTap;

  const SwipeableCard({
    super.key,
    required this.child,
    required this.onSwipe,
    this.onTap,
  });

  @override
  State<SwipeableCard> createState() => _SwipeableCardState();
}

class _SwipeableCardState extends State<SwipeableCard> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _animation;
  late Animation<double> _rotation;
  Offset _dragStart = Offset.zero;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _animation = Tween<Offset>(begin: Offset.zero, end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
    _rotation = Tween<double>(begin: 0, end: 0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onPanStart(DragStartDetails details) {
    setState(() {
      _isDragging = true;
      _dragStart = details.globalPosition;
    });
  }

  void _onPanUpdate(DragUpdateDetails details) {
    final delta = details.globalPosition - _dragStart;
    setState(() {
      _animation = Tween<Offset>(
        begin: Offset(delta.dx / context.size!.width, 0),
        end: Offset(delta.dx / context.size!.width, 0),
      ).animate(_controller);
      
      _rotation = Tween<double>(
        begin: (delta.dx / context.size!.width) * 0.4,
        end: (delta.dx / context.size!.width) * 0.4,
      ).animate(_controller);
    });
  }

  void _onPanEnd(DragEndDetails details) {
    final delta = details.velocity.pixelsPerSecond;
    final swipeThreshold = context.size!.width * 0.4;
    
    if (delta.dx.abs() > swipeThreshold || _animation.value.dx.abs() > 0.4) {
      final direction = delta.dx > 0 ? SwipeDirection.right : SwipeDirection.left;
      _animateSwipe(direction);
    } else {
      _resetPosition();
    }
    setState(() => _isDragging = false);
  }

  void _animateSwipe(SwipeDirection direction) {
    final endX = direction == SwipeDirection.right ? 2.0 : -2.0;
    _animation = Tween<Offset>(
      begin: _animation.value,
      end: Offset(endX, 0),
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
    
    _rotation = Tween<double>(
      begin: _rotation.value,
      end: endX * 0.4,
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _controller.forward().then((_) {
      widget.onSwipe(direction);
    });
  }

  void _resetPosition() {
    _animation = Tween<Offset>(
      begin: _animation.value,
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
    
    _rotation = Tween<double>(
      begin: _rotation.value,
      end: 0,
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _controller.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: _onPanStart,
      onPanUpdate: _onPanUpdate,
      onPanEnd: _onPanEnd,
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(
              _animation.value.dx * context.size!.width,
              0,
            ),
            child: Transform.rotate(
              angle: _rotation.value,
              child: Stack(
                children: [
                  child!,
                  if (_isDragging) ...[
                    _buildSwipeIndicator(
                      context,
                      _animation.value.dx > 0 ? Colors.green : Colors.red,
                      _animation.value.dx > 0 ? 'APPROVE' : 'DISMISS',
                      _animation.value.dx.abs(),
                    ),
                  ],
                ],
              ),
            ),
          );
        },
        child: widget.child,
      ),
    );
  }

  Widget _buildSwipeIndicator(
    BuildContext context,
    Color color,
    String text,
    double progress,
  ) {
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: color.withOpacity(progress),
            width: 4,
          ),
        ),
        child: Center(
          child: Transform.rotate(
            angle: progress > 0 ? 0 : 3.14,
            child: Text(
              text,
              style: TextStyle(
                color: color.withOpacity(progress),
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
} 