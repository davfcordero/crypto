import 'package:flutter/material.dart';
import 'package:crypto_tarot/models/crypto_signal.dart';
import 'package:crypto_tarot/widgets/swipeable_card.dart';
import 'package:fl_chart/fl_chart.dart';

class SignalCard extends StatelessWidget {
  final CryptoSignal signal;
  final Function(bool approved) onSwipe;
  final VoidCallback onTap;

  const SignalCard({
    super.key,
    required this.signal,
    required this.onSwipe,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SwipeableCard(
      onSwipe: (direction) {
        onSwipe(direction == SwipeDirection.right);
      },
      onTap: onTap,
      child: Card(
        elevation: 8,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Container(
          width: 300,
          height: 400,
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(theme),
              const SizedBox(height: 16),
              _buildPriceChart(theme),
              const SizedBox(height: 16),
              _buildPrediction(theme),
              const Spacer(),
              _buildConfidence(theme),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 6,
          ),
          decoration: BoxDecoration(
            color: _getSignalColor(signal.signal).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            signal.signal.toUpperCase(),
            style: theme.textTheme.titleMedium?.copyWith(
              color: _getSignalColor(signal.signal),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const Spacer(),
        Text(
          signal.cryptocurrency.toUpperCase(),
          style: theme.textTheme.titleLarge,
        ),
      ],
    );
  }

  Widget _buildPriceChart(ThemeData theme) {
    return SizedBox(
      height: 150,
      child: LineChart(
        LineChartData(
          gridData: const FlGridData(show: false),
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: false),
          lineBarsData: [
            LineChartBarData(
              spots: signal.priceHistory.asMap().entries.map((entry) {
                return FlSpot(entry.key.toDouble(), entry.value);
              }).toList(),
              isCurved: true,
              color: theme.colorScheme.primary,
              barWidth: 3,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                color: theme.colorScheme.primary.withOpacity(0.1),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPrediction(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          signal.prediction,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          signal.explanation,
          style: theme.textTheme.bodyMedium,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  Widget _buildConfidence(ThemeData theme) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Icon(
          Icons.auto_awesome,
          color: theme.colorScheme.primary,
          size: 16,
        ),
        const SizedBox(width: 4),
        Text(
          '${(signal.confidence * 100).toInt()}% Confidence',
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.primary,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Color _getSignalColor(String signal) {
    switch (signal.toLowerCase()) {
      case 'buy':
        return Colors.green;
      case 'sell':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }
} 