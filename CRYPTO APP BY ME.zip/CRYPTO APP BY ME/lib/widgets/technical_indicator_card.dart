import 'package:flutter/material.dart';

class TechnicalIndicatorCard extends StatelessWidget {
  final String title;
  final String value;
  final String interpretation;

  const TechnicalIndicatorCard({
    super.key,
    required this.title,
    required this.value,
    required this.interpretation,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: theme.textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.primary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              interpretation,
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
} 