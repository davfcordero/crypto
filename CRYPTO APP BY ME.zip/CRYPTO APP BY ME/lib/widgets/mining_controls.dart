import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class MiningControls extends StatelessWidget {
  final double hashPower;
  final bool isMining;
  final Function(double) onHashPowerChanged;
  final VoidCallback onToggleMining;

  const MiningControls({
    super.key,
    required this.hashPower,
    required this.isMining,
    required this.onHashPowerChanged,
    required this.onToggleMining,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Mining Power',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              _buildLevelBadge(context),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              const Icon(Icons.bolt),
              Expanded(
                child: Slider(
                  value: hashPower,
                  min: 0,
                  max: 100,
                  divisions: 20,
                  label: '${hashPower.round()} MH/s',
                  onChanged: onHashPowerChanged,
                ),
              ),
              const Icon(Icons.bolt_outlined),
            ],
          ),
          const SizedBox(height: 20),
          _buildMiningButton(context),
          if (isMining) _buildBoostButton(context),
        ],
      ),
    );
  }

  Widget _buildLevelBadge(BuildContext context) {
    final level = (hashPower / 10).floor();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.stars, size: 16),
          const SizedBox(width: 4),
          Text(
            'Level $level',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildMiningButton(BuildContext context) {
    return ElevatedButton(
      onPressed: onToggleMining,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(isMining ? Icons.stop : Icons.play_arrow),
          const SizedBox(width: 8),
          Text(isMining ? 'Stop Mining' : 'Start Mining'),
        ],
      ),
    );
  }

  Widget _buildBoostButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: OutlinedButton(
        onPressed: () {
          // Show boost dialog with rewards
        },
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.flash_on),
            SizedBox(width: 8),
            Text('Boost Mining (2x)'),
          ],
        ),
      ),
    );
  }
} 