import 'package:flutter/material.dart';

class GPUManagementCard extends StatelessWidget {
  final int gpuCount;
  final VoidCallback onAddGPU;
  final VoidCallback onRemoveGPU;
  final double efficiency;
  final ValueChanged<double> onUpdateEfficiency;

  const GPUManagementCard({
    super.key,
    required this.gpuCount,
    required this.onAddGPU,
    required this.onRemoveGPU,
    required this.efficiency,
    required this.onUpdateEfficiency,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'GPU Management',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('GPUs: $gpuCount'),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.remove),
                      onPressed: gpuCount > 1 ? onRemoveGPU : null,
                    ),
                    IconButton(
                      icon: const Icon(Icons.add),
                      onPressed: gpuCount < 8 ? onAddGPU : null,
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'Efficiency: ${(efficiency * 100).toInt()}%',
              style: theme.textTheme.titleSmall,
            ),
            Slider(
              value: efficiency,
              min: 0.1,
              max: 1.0,
              divisions: 9,
              label: '${(efficiency * 100).toInt()}%',
              onChanged: onUpdateEfficiency,
            ),
          ],
        ),
      ),
    );
  }
} 