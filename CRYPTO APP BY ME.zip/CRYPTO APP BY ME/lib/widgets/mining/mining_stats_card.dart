import 'package:flutter/material.dart';
import 'package:crypto_tarot/models/mining_stats.dart';

class MiningStatsCard extends StatelessWidget {
  final MiningStats stats;

  const MiningStatsCard({
    super.key,
    required this.stats,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Mining Statistics',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            _buildStatRow(
              theme,
              'Total Earnings',
              '${stats.earnings.toStringAsFixed(2)} CT',
              Icons.account_balance_wallet,
            ),
            const Divider(),
            _buildStatRow(
              theme,
              'Daily Profit',
              '${stats.dailyProfit.toStringAsFixed(2)} CT',
              Icons.trending_up,
            ),
            const Divider(),
            _buildStatRow(
              theme,
              'Power Usage',
              '${stats.powerConsumption.toInt()}W',
              Icons.electric_bolt,
            ),
            const Divider(),
            _buildStatRow(
              theme,
              'Operating Cost',
              '${stats.dailyOperatingCost.toStringAsFixed(2)} CT/day',
              Icons.money_off,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(ThemeData theme, String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 20, color: theme.colorScheme.primary),
          const SizedBox(width: 8),
          Text(label, style: theme.textTheme.bodyMedium),
          const Spacer(),
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}