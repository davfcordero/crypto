import 'package:flutter/material.dart';
import 'package:crypto_tarot/models/mining_stats.dart';

class MiningProgressCard extends StatelessWidget {
  final MiningStats stats;
  final VoidCallback onToggleMining;

  const MiningProgressCard({
    super.key,
    required this.stats,
    required this.onToggleMining,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Mining Progress',
                  style: theme.textTheme.titleLarge,
                ),
                IconButton(
                  icon: Icon(
                    stats.isAutoMining ? Icons.pause : Icons.play_arrow,
                    color: stats.isAutoMining ? Colors.red : Colors.green,
                  ),
                  onPressed: onToggleMining,
                ),
              ],
            ),
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: stats.isAutoMining ? null : 0,
              backgroundColor: theme.colorScheme.primary.withOpacity(0.1),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Hash Rate',
                      style: theme.textTheme.bodySmall,
                    ),
                    Text(
                      '${stats.hashPower.toStringAsFixed(1)} H/s',
                      style: theme.textTheme.titleMedium,
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Earnings/Hour',
                      style: theme.textTheme.bodySmall,
                    ),
                    Text(
                      '${stats.hourlyEarnings.toStringAsFixed(2)} CT',
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: theme.colorScheme.primary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
} 