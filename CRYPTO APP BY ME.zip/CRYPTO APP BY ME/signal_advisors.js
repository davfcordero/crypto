class SignalAdvisor {
    constructor(type) {
        this.type = type;
        this.model = null;
        this.speechBubble = null;
        this.personality = ADVISOR_PROFILES[type];
        this.init();
    }

    static TYPES = {
        CONSERVATIVE: 'conservative',
        MODERATE: 'moderate',
        AGGRESSIVE: 'aggressive'
    };
}

const ADVISOR_PROFILES = {
    conservative: {
        name: 'Sage Oracle',
        model: 'assets/models/sage_advisor.glb',
        color: 0x4287f5,
        riskTolerance: 0.3,
        minConfidence: 0.8,
        speechStyle: 'cautious',
        animations: ['idle', 'speak', 'nod', 'think'],
        description: 'Focuses on stable, low-risk opportunities with consistent returns.',
        catchphrase: 'Patience builds fortunes.',
    },
    moderate: {
        name: 'Tech Strategist',
        model: 'assets/models/tech_advisor.glb',
        color: 0x42f5a7,
        riskTolerance: 0.6,
        minConfidence: 0.65,
        speechStyle: 'analytical',
        animations: ['idle', 'speak', 'gesture', 'analyze'],
        description: 'Balances risk and reward using data-driven analysis.',
        catchphrase: 'The trend is your friend.',
    },
    aggressive: {
        name: 'Crypto Maverick',
        model: 'assets/models/maverick_advisor.glb',
        color: 0xf54242,
        riskTolerance: 0.9,
        minConfidence: 0.5,
        speechStyle: 'bold',
        animations: ['idle', 'speak', 'celebrate', 'alert'],
        description: 'Seeks high-reward opportunities in volatile markets.',
        catchphrase: 'Fortune favors the bold!',
    }
}; 