# Crypto Tarot - Your Daily Market Oracle
A cutting-edge Flutter application that combines cryptocurrency trading signals with an engaging tarot card interface.

## Setup Instructions
1. Get API keys for:
   - CoinGecko/CoinMarketCap API (for crypto data)
   - OpenAI API (for AI predictions)
2. Create a `.env` file in the project root with your API keys
3. Run `flutter pub get` to install dependencies
4. Run `flutter run` to start the app

## Project Structure
