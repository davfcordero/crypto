class AdvisorInteractions {
    constructor(advisor) {
        this.advisor = advisor;
        this.currentAnimation = 'idle';
        this.emotionalState = 'neutral';
        this.setupEmotions();
    }

    setupEmotions() {
        this.emotions = {
            excited: {
                animation: 'celebrate',
                color: 0x00ff00,
                particleEffect: 'sparkles',
                soundEffect: 'celebration.mp3'
            },
            concerned: {
                animation: 'alert',
                color: 0xff0000,
                particleEffect: 'warning',
                soundEffect: 'alert.mp3'
            },
            thoughtful: {
                animation: 'think',
                color: 0x0000ff,
                particleEffect: 'bubbles',
                soundEffect: 'thinking.mp3'
            }
        };
    }

    async presentSignal(signal) {
        const emotion = this.determineEmotion(signal);
        await this.transitionToEmotion(emotion);
        
        // Create and animate speech bubble
        const bubble = new EnhancedSpeechBubble(
            this.generateSpeech(signal),
            this.advisor.personality.color,
            emotion
        );
        
        await bubble.appear();
        await this.playSignalAnimation(signal);
        await bubble.disappear();
        
        this.returnToIdle();
    }

    determineEmotion(signal) {
        if (signal.confidence > 0.8) return 'excited';
        if (signal.analysis.risk > 0.7) return 'concerned';
        return 'thoughtful';
    }

    async playSignalAnimation(signal) {
        const sequence = this.getAnimationSequence(signal);
        
        for (const animation of sequence) {
            await this.playAnimation(animation);
        }
    }

    getAnimationSequence(signal) {
        const baseSequence = ['think', 'gesture', 'speak'];
        
        if (signal.confidence > 0.8) {
            baseSequence.push('celebrate');
        }
        
        if (signal.analysis.risk > 0.7) {
            baseSequence.push('alert');
        }
        
        return baseSequence;
    }
}

class EnhancedSpeechBubble {
    constructor(text, color, emotion) {
        this.text = text;
        this.color = color;
        this.emotion = emotion;
        this.element = this.create();
    }

    create() {
        const bubble = new THREE.Group();
        
        // Create dynamic bubble shape based on emotion
        const shape = this.createEmotionalShape();
        const material = this.createEmotionalMaterial();
        
        const bubbleMesh = new THREE.Mesh(shape, material);
        bubble.add(bubbleMesh);
        
        // Add text with emotional styling
        const textMesh = this.createStylizedText();
        bubble.add(textMesh);
        
        // Add emotional particles
        const particles = this.createEmotionalParticles();
        bubble.add(particles);
        
        return bubble;
    }

    async appear() {
        // Animate bubble appearance with emotional effects
        return new Promise(resolve => {
            gsap.from(this.element.scale, {
                x: 0, y: 0, z: 0,
                duration: 0.5,
                ease: 'elastic.out',
                onComplete: resolve
            });
        });
    }

    // Additional methods for bubble animations and effects...
} 