import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:crypto_tarot/screens/splash_screen.dart';
import 'package:crypto_tarot/theme/app_theme_mode.dart';
import 'package:shared_preferences.dart';
import 'package:crypto_tarot/services/storage_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  
  runApp(
    ProviderScope(
      overrides: [
        storageServiceProvider.overrideWithValue(StorageService(prefs)),
      ],
      child: const CryptoTarotApp(),
    ),
  );
}

class CryptoTarotApp extends ConsumerWidget {
  const CryptoTarotApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = ref.watch(themeProvider);

    return MaterialApp(
      title: 'Crypto Tarot',
      theme: theme,
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}