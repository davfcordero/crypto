class CryptoBackground {
    constructor() {
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        this.clock = new THREE.Clock();
        this.objects = [];
        
        this.init();
        this.animate();
    }

    init() {
        // Setup renderer
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        document.querySelector('.background-canvas').appendChild(this.renderer.domElement);

        // Add shader background
        const shaderMaterial = new THREE.ShaderMaterial({
            uniforms: {
                time: { value: 0 },
                resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) }
            },
            vertexShader,
            fragmentShader,
            transparent: true
        });

        const plane = new THREE.Mesh(
            new THREE.PlaneGeometry(50, 50),
            shaderMaterial
        );
        plane.position.z = -10;
        this.scene.add(plane);

        // Add floating crypto symbols
        const loader = new THREE.FontLoader();
        loader.load('path/to/font.json', (font) => {
            const symbols = ['₿', 'Ξ', '◈', '∞', '₮', 'Ł'];
            symbols.forEach(symbol => {
                const geometry = new THREE.TextGeometry(symbol, {
                    font: font,
                    size: 1,
                    height: 0.2,
                    curveSegments: 12,
                    bevelEnabled: true,
                    bevelThickness: 0.03,
                    bevelSize: 0.02,
                    bevelOffset: 0,
                    bevelSegments: 5
                });

                const material = new THREE.MeshPhongMaterial({
                    color: 0x6B4EFF,
                    transparent: true,
                    opacity: 0.6,
                    specular: 0xffffff,
                    shininess: 100
                });

                const mesh = new THREE.Mesh(geometry, material);
                mesh.position.set(
                    Math.random() * 40 - 20,
                    Math.random() * 40 - 20,
                    Math.random() * 10 - 5
                );
                
                mesh.userData = {
                    rotationSpeed: {
                        x: Math.random() * 0.02 - 0.01,
                        y: Math.random() * 0.02 - 0.01,
                        z: Math.random() * 0.02 - 0.01
                    },
                    floatSpeed: Math.random() * 0.01 + 0.005
                };

                this.objects.push(mesh);
                this.scene.add(mesh);
            });
        });

        // Add lights
        const pointLight = new THREE.PointLight(0xffffff, 1, 100);
        pointLight.position.set(10, 10, 10);
        this.scene.add(pointLight);

        const ambientLight = new THREE.AmbientLight(0x404040);
        this.scene.add(ambientLight);

        // Position camera
        this.camera.position.z = 15;

        // Add mouse interaction
        document.addEventListener('mousemove', (e) => this.onMouseMove(e));
        window.addEventListener('resize', () => this.onWindowResize());
    }

    onMouseMove(event) {
        const mouseX = (event.clientX / window.innerWidth) * 2 - 1;
        const mouseY = -(event.clientY / window.innerHeight) * 2 + 1;

        this.objects.forEach(obj => {
            gsap.to(obj.rotation, {
                x: mouseY * 0.2,
                y: mouseX * 0.2,
                duration: 1,
                ease: 'power2.out'
            });
        });
    }

    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        const time = this.clock.getElapsedTime();

        // Update shader uniforms
        this.scene.children.forEach(child => {
            if (child.material && child.material.uniforms) {
                child.material.uniforms.time.value = time;
            }
        });

        // Animate floating symbols
        this.objects.forEach(obj => {
            obj.rotation.x += obj.userData.rotationSpeed.x;
            obj.rotation.y += obj.userData.rotationSpeed.y;
            obj.rotation.z += obj.userData.rotationSpeed.z;
            
            obj.position.y += Math.sin(time) * obj.userData.floatSpeed;
        });

        this.renderer.render(this.scene, this.camera);
    }
}

// Initialize the enhanced background
const cryptoBackground = new CryptoBackground(); 